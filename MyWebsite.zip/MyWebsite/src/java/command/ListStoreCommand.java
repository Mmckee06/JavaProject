/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

/**
 *
 * @author Michael
 */
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import JavaClasses.Store;
import Services.StoreService;
import java.net.URL;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
/**
 *
 * @author Michael
 */
public class ListStoreCommand implements Command {
    private static final Logger logger = Logger.getLogger(ListStoreCommand .class.getName());
    
    
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        //Check to see if the session id coming from the client matches the id stored at login...
        HttpSession session = request.getSession();
        String forwardToJsp;
        
        
        try {
        //User not logged in...
        if ( session.getId() != session.getAttribute("loggedSessionId") )
        {
            StoreService StoreService = new StoreService();
            //Make the call to the 'Model' by using the UserService class to get all Users...
            List<Store> items = StoreService.getAllItems();
            //Put the list of users into the session so that JSP(the View) can pick them up & display them...
            session.setAttribute("items", items);
            forwardToJsp = "/Store.jsp";
            logger.info("Store displayed, User not logged in");
        }
        else
        {	
            StoreService StoreService = new StoreService();
            //Make the call to the 'Model' by using the UserService class to get all Users...
            List<Store> items = StoreService.getAllItems();
            //Put the list of users into the session so that JSP(the View) can pick them up & display them...
            session.setAttribute("items", items);
            forwardToJsp = "/Store.jsp";
            logger.info("User Logged in and Store displayed correctly");
        }
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/Store.jsp";
            logger.warn("NumberFormatException occured in List Store Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Store.jsp";
            logger.warn("Null Point Exception occured in List Store Command");
            return forwardToJsp; 
        }
    }
}
    


