/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;
import JavaClasses.PremTable;
import Services.TableService;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
/**
 *
 * @author Michael
 */
public class UpdateTableCommand implements Command {
    private static final Logger logger = Logger.getLogger(UpdateTableCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
    try {    
        //The user wants to Edit...
        String teamname = request.getParameter("teamName");
        int GamesPlayed = Integer.parseInt(request.getParameter("GamesPlayed"));
        int GoalsFor = Integer.parseInt(request.getParameter("GoalsFor"));
        int GoalsAgainst = Integer.parseInt(request.getParameter("GoalsAgainst"));
        int GoalDifference = Integer.parseInt(request.getParameter("GoalDifference"));
        int points = Integer.parseInt(request.getParameter("points"));
       
        if (teamname != null && GamesPlayed >= 0 )
        {
            //Use the UserServive class to login...
            TableService TableService = new TableService();
            PremTable tableEdit = TableService.Edit(teamname, GamesPlayed, GoalsFor, GoalsAgainst, GoalDifference, points);

            if (tableEdit != null)
            {
                logger.info(teamname + " edited");
                forwardToJsp = "/UserActionServlet?action=List Teams1";			
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=List Teams1";	
                logger.info("Couldn't find team to edit");
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=List Teams1"; 
            logger.info("Missing information, Team not updated");
        }
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=List Teams1";
            logger.warn("NumberFormatException occured in Update Table Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=List Teams1";
            logger.warn("Null Point Exception occured in Update Table Command");
            return forwardToJsp; 
        }
    }
}
