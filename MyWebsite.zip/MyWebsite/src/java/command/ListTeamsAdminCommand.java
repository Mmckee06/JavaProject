/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.PremTable;
import Services.TableService;
import java.net.URL;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class ListTeamsAdminCommand implements Command {
    
    private static final Logger logger = Logger.getLogger(ListTeamsAdminCommand.class.getName());
    
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);

        //Check to see if the session id coming from the client matches the id stored at login...
        HttpSession session = request.getSession();
        String forwardToJsp;
        
        try {
        
        if ( session.getId() != session.getAttribute("loggedSessionId") )
        {
            TableService StoreService = new TableService();
            List<PremTable> teams = StoreService.getAllTeams();
            session.setAttribute("teams", teams);
            forwardToJsp = "/AdminTable.jsp";
            logger.info("Prem table displayed (Admin)");
        }
        else
        {	
            TableService StoreService = new TableService();
            //Make the call to the 'Model' by using the TableService class to get all Teams...
            List<PremTable> teams = StoreService.getAllTeams();
            //Put the list of teams into the session so that JSP(the View) can pick them up & display them...
            session.setAttribute("teams", teams);
            forwardToJsp = "/AdminTable.jsp";
            logger.info("Prem table displayed, Admin");
        }
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/AdminTable.jsp";
            logger.warn("NumberFormatException occured in List Teams Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/AdminTable.jsp";
            logger.warn("Null Point Exception occured in List Teams Command");
            return forwardToJsp; 
        }
    } 
    
}
