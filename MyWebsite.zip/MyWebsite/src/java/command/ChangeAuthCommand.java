/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.User;
import Services.UserService;
import static command.AddToBasketCommand.generateCSRFToken;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class ChangeAuthCommand implements Command {
    private static final Logger logger = Logger.getLogger(ChangeAdminCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
       try {  
        //The user wants to Register...
         HttpSession session = request.getSession();
        String username = testImput(request.getParameter("Uname"));
        String csrfToken = (String) request.getParameter("token");
        String storedToken = (String)session.getAttribute("csrfToken");
        
        //do check
       String csrfToken1 = org.apache.commons.lang3.StringUtils.substring(csrfToken, 0, 26);
       String storedToken1 = org.apache.commons.lang3.StringUtils.substring(storedToken, 0, 26);
        
       if (storedToken1.equals(csrfToken1)) {
               session.setAttribute("csrfToken", generateCSRFToken());
        
        if (username != null)
        {
            //Use the UserServive class to login...
            UserService userService = new UserService();
            User changeAdmin = userService.ChangeGoogleAuth(username, 0);
            logger.info(username + " auth now turned off");

            if (changeAdmin != null)
            {
                forwardToJsp = "/UserActionServlet?action=ListUsers";	//Logged in			
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=ListUsers";	//Failed Login
            }
        }
        else 
        {
            logger.warn("Username not Found");
            forwardToJsp = "/UserActionServlet?action=ListUsers"; //Failed Login	
        }
        
        return forwardToJsp;
       
       } else {
            forwardToJsp = "/Homepage.jsp";
            session.invalidate();
            return forwardToJsp;
        }
       
        
        }   catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=ListUsers";
            logger.warn("NumberFormatException occured in Change Admin");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=ListUsers";
            logger.warn("Null Point Exception occured in Change Admin");
            return forwardToJsp; 
        }
       
    }
    
    public String testImput(String Input) {
        Input = Input.replace("&", "&amp;");
        Input = Input.replace("<", "&lt;");
        Input = Input.replace(">", "&gt;");
        Input = Input.replace("\"", "&quot;");
        Input = Input.replace("'", "&#x27;");
        Input = Input.replace("/", "&#x2F; ");
        return Input;
    }
    
}
