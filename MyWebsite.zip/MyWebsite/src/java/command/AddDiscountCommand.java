/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.Store;
import Services.StoreService;
import java.net.URL;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class AddDiscountCommand implements Command{
    private static final Logger logger = Logger.getLogger(AddDiscountCommand.class.getName());
    
   public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        //The user wants to Edit...
  try {      
        
        double discount = Double.parseDouble(request.getParameter("discount"));
        
     
        if (discount > 0 && discount < 100  )
        {
            
            //Use the UserServive class to login...
            StoreService storeService = new StoreService();
            Store itemDiscount = storeService.giveDdiscount(discount);
            
            if (itemDiscount != null)
            {
                forwardToJsp = "/UserActionServlet?action=List Items";	
                logger.info("Discount Added");
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=List Items";
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=List Items"; 
            logger.info("Discount not between 0 and 100");
        }
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.warn("NumberFormatException occured in Edit Item Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.warn("Null Point Exception occured in Edit Item Command");
            return forwardToJsp; 
        }
    }
}
