/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import JavaClasses.Store;
import Services.StoreService;
import java.net.URL;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class ListItemsCommand implements Command {
    private static final Logger logger = Logger.getLogger(ListItemsCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        HttpSession session = request.getSession();
        

        //User not logged in...
        if ( session.getId() != session.getAttribute("loggedSessionId") )
        {
            forwardToJsp = "/Homepage.jsp";
            logger.info("Session expired");
        }
        else
        {	
            StoreService StoreService = new StoreService();
            List<Store> items = StoreService.getAllItems();
            session.setAttribute("items", items);
            logger.info("Store items listed Sucessfully (Admin)");
            forwardToJsp = "/AdminStore.jsp";
        }
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/AdminStore.jsp";
            logger.warn("NumberFormatException occured in List Items Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/AdminStore.jsp";
            logger.warn("Null Point Exception occured in List Items Command");
            return forwardToJsp; 
        }
    }
}
    

