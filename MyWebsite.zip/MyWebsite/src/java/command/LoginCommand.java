/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

/**
 *
 * @author Michael
 */
import JavaClasses.Store;
import JavaClasses.User;
import JavaClasses.googleAuth;
import Services.StoreService;
import Services.UserService;
import Services.googleAuthService;
import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;
import java.io.Serializable;
import java.math.BigInteger;
import java.net.URL;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class LoginCommand implements Command 
{
        private static final Logger logger = Logger.getLogger(LoginCommand.class.getName());
        
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        //The user wants to log in...
        String username = request.getParameter("Uname");
        String password = request.getParameter("password");

        if (username != null || password != null)
        {
            //Use the UserServive class to login...
            UserService userService = new UserService();
            User userLoggingIn = userService.login(username, password);

            if (userLoggingIn != null )
            {
                 if (userLoggingIn.getGoogleAuth() == 0){
                //If login successful, store the session id for this client...
                HttpSession session = request.getSession();
                session.invalidate();
                session=request.getSession(true); 
                String clientSessionId = session.getId();
                session.setAttribute("loggedSessionId", clientSessionId);
                session.setAttribute("user", userLoggingIn);
                session.setAttribute("authCode", userLoggingIn.getGoogleAuth());
                session.setAttribute("csrfToken", generateCSRFToken());
                // create basket
                ArrayList<Store>  SessionItems = new ArrayList<Store>();
                session.setAttribute("basket",SessionItems );
                
                //Adding an Iitem to the basket
                //Store addItem1 = new Store("football", "football", 5.99);
                //SessionItems.add(addItem1);
                forwardToJsp = "/Homepage.jsp";	//Logged in
                 logger.info("User " + username + " logged in successfully");   
                } else if(userLoggingIn.getGoogleAuth() == 1){
                    
                    HttpSession session = request.getSession();
                    session.invalidate();
                    session=request.getSession(true); 
                    googleAuthService s1 = new googleAuthService();
                    session.setAttribute("user", userLoggingIn);
                    googleAuth a = s1.FindUser(username);
                    GoogleAuthenticator googleAuthenticator = new GoogleAuthenticator();
                
        final GoogleAuthenticatorKey key = googleAuthenticator.createCredentials(username); 
        final String secretKey = a.getKey();
        final List<Integer> scratchCodes = key.getScratchCodes();
        
        String urlImage = GoogleAuthenticatorKey.getQRBarcodeURL(username, "footyWebsite", secretKey);
        
        session.setAttribute("KeyImage", urlImage); 
        session.setAttribute("secretKey", secretKey); 
                forwardToJsp = "/Login2.jsp";
                logger.info("User send to Login2 Auth")	;
                } else {
                     forwardToJsp = "/Homepage.jsp";
                }
            }
            else
            {
                forwardToJsp = "/Login.jsp";	//Failed Login
                logger.warn("Usermane and password don't match");
            }
        }
        else 
        {
            forwardToJsp = "/Login.jsp"; //Failed Login	
            logger.info("User missing username or password");
        }
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/Login.jsp";
            logger.warn("NumberFormatException occured in Logon Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Login.jsp";
            logger.warn("Null Point Exception occured in Logon Command");
            return forwardToJsp; 
        }
    }
    
      //sample implementation of token generation
public static String generateCSRFToken() {
   SecureRandom random = new SecureRandom();
   return new BigInteger(130, random).toString(32);
}
}
