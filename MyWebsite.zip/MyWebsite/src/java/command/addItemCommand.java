/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import JavaClasses.Store;
import Services.StoreService;
import java.net.URL;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class addItemCommand implements Command {
    private static final Logger logger = Logger.getLogger(addItemCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
    try {    
        //The user wants to add Item...
        //int id = Integer.parseInt(request.getParameter("id"));
        String itemName = request.getParameter("itemName");
        String itemType = request.getParameter("itemType");
        int qua = Integer.parseInt(request.getParameter("quantity"));
        double price = Double.parseDouble(request.getParameter("price"));
        String image = request.getParameter("Image");
        
        if (itemName != null || itemType != null || price < 0)
        {
            //Use the UserServive class to login...
            StoreService storeService = new StoreService();
            Store addItem1 = storeService.addItem(itemName, itemType,qua, price,image);

            if (addItem1 != null)
            {
                logger.info(itemName + " added Successfully");
                forwardToJsp = "/UserActionServlet?action=List Items";				
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=List Items";	
                logger.info(itemName + " not added");
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=List Items"; 
            logger.info("Item not added due to missing information");
        }
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.warn("NumberFormatException occured in add Items Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.warn("Null Point Exception occured in add Items Command");
            return forwardToJsp; 
        }
    }
    
}
