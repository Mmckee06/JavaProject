/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.Product_Order;
import JavaClasses.Sales_Order;
import Services.Product_OrderService;
import Services.Sales_OrderService;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
/**
 *
 * @author Michael
 */
public class DeleteSaleCommand implements Command{
    private static final Logger logger = Logger.getLogger(DeleteSaleCommand.class.getName());
    
     public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        int id  = Integer.parseInt(request.getParameter("salesID"));
        
        if (id >= 0)
        {
            
            Product_OrderService productService = new Product_OrderService();
            Product_Order DeleteProduct = productService.DeleteProductBySalesID(id);
            
            Sales_OrderService saleService = new Sales_OrderService();
            Sales_Order DeleteSale = saleService.DeleteBySalesID(id);
            
            

            
            if (DeleteSale != null)
            {
                forwardToJsp = "/UserActionServlet?action=List Orders";	
                logger.info("Sales Id (" + id + ") and related Sales line deleted");
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=List Orders";	
                logger.info("Sales Id not found for deleting Sale");
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=List Orders"; 	
            logger.info("Sales Id valid for deleting Sale");
        }
        
        return forwardToJsp;
        
        }   catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=List Orders";
            logger.warn("NumberFormatException occured in Delete Sale Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=List Orders";
            logger.warn("Null Point Exception occured in Delete Sale Command");
            return forwardToJsp; 
        }
    }
    
}
