/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

/**
 *
 * @author Michael
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import JavaClasses.User;
import Services.UserService;
import java.net.URL;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;


public class RegisterCommand implements Command {
private static final Logger logger = Logger.getLogger(RegisterCommand.class.getName());

    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
   try {     
        //The user wants to Register...
        String username = request.getParameter("Uname");
        String password = request.getParameter("password");
        String LastName = request.getParameter("lname");
        String FirstName = request.getParameter("fname");
        String Address1 = request.getParameter("Address1");
        String Address2 = request.getParameter("Address2");
        String city = request.getParameter("city");
        String pcode = request.getParameter("pcode");
        String phone = request.getParameter("phone");
        int user_Type = 0;
        int googleAuth = 0;
        
        if (username != null || password != null || LastName != null || FirstName != null || Address1 != null)
        {
            //Use the UserServive class to login...
            UserService userService = new UserService();
            User userRegister = userService.Register(username,password,LastName,FirstName,Address1,Address2,city,pcode,phone,user_Type,googleAuth );

            if (userRegister != null)
            {
                logger.info(username + " is now a new member");
                forwardToJsp = "/SuccessfulLogin.jsp";				
            }
            else
            {
                forwardToJsp = "/Register.jsp";	
            }
        }
        else 
        {
            forwardToJsp = "/Register.jsp"; 
            logger.info("User had unsuccessfully register (missing information)");
        }
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/Register.jsp";
            logger.warn("NumberFormatException occured in Register Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Register.jsp";
            logger.warn("Null Point Exception occured in Register Command");
            return forwardToJsp; 
        }
    }
}
