/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;
import JavaClasses.Store;
import Services.StoreService;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
/**
 *
 * @author Michael
 */
public class EditItemCommand implements Command  {
    private static final Logger logger = Logger.getLogger(EditItemCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        //The user wants to Edit...
  try {      
        int ID = Integer.parseInt(request.getParameter("ID"));
        String ItemName = request.getParameter("ItemName");
        String ItemType = request.getParameter("ItemType");
        int qua = Integer.parseInt(request.getParameter("quantity"));
        double price = Double.parseDouble(request.getParameter("price"));
        String image = request.getParameter("Image");
     
        if (ItemName != null && ItemType != null && qua >=0 && price > 0 && image != null )
        {
            
            //Use the UserServive class to login...
            StoreService storeService = new StoreService();
            Store itemEdit = storeService.Edit(ID,ItemName,ItemType,qua,price,image);
            
            if (itemEdit != null)
            {
                forwardToJsp = "/UserActionServlet?action=List Items";	
                logger.info("Item " + ItemName + " successfully edited");
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=List Items";
                logger.info("Item ID " + ID + " not found");
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=List Items"; 
            logger.info("Item had missing information so wasn't edited");
        }
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.warn("NumberFormatException occured in Edit Item Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.warn("Null Point Exception occured in Edit Item Command");
            return forwardToJsp; 
        }
    }
  
  
    
}
