/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.Store;
import Services.StoreService;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
/**
 *
 * @author Michael
 */
public class DeleteItemCommand implements Command{
    
    private static final Logger logger = Logger.getLogger(DeleteItemCommand.class.getName());
     public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        //The user wants to Delete...
        int id  = Integer.parseInt(request.getParameter("id"));
        
        
        if (id >=0)
        {
            
            StoreService storeService = new StoreService();
            Store Deleteitem = storeService.DeleteItem(id);
            

            if (Deleteitem != null)
            {
               
                forwardToJsp = "/UserActionServlet?action=List Items";
                logger.info("Item with id= " + id + " deleted from store");
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=List Items";	
                logger.info("Item with id= " + id + " not found to delete from store");
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.info("ID not valid to delete");
        }
        
        return forwardToJsp;
        
        }   catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.warn("NumberFormatException occured in Delete Item Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=List Items";
            logger.warn("Null Point Exception occured in Delete Item Command");
            return forwardToJsp; 
        }
    }
    
}
