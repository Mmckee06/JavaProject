/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;


import JavaClasses.googleAuth;
import Services.googleAuthService;
import java.net.URL;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class ListGoogleAuthCommand implements Command {
    private static final Logger logger = Logger.getLogger(ListGoogleAuthCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        //Check to see if the session id coming from the client matches the id stored at login...
        HttpSession session = request.getSession();
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        //User not logged in...
        if ( session.getId() != session.getAttribute("loggedSessionId") )
        {
            forwardToJsp = "/Homepage.jsp";
            logger.info("Session expired");
        }
        else
        {	
            googleAuthService googleAuthService = new googleAuthService();
            //Make the call to the 'Model' by using the UserService class to get all Users...
            List<googleAuth> auths = googleAuthService.getAllAuths();
            //Put the list of auths into the session so that JSP(the View) can pick them up & display them...
            session.setAttribute("googleAuths", auths);
            logger.info("Google Auth listed Successfully (Admin)");
            forwardToJsp = "/googleAuthAdmin.jsp";
        }
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/googleAuthAdmin.jsp";
            logger.warn("NumberFormatException occured in List Orders Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/googleAuthAdmin.jsp";
            logger.warn("Null Point Exception occured in List Orders Command");
            return forwardToJsp; 
        }
    }
    
}

   
