/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

/**
 *
 * @author Michael
 */
import java.net.URL;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class LogoutCommand implements Command 
{
    private static final Logger logger = Logger.getLogger(LogoutCommand.class.getName());

    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
       String forwardToJsp; 
       
       URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
            
        // Get the session object and invalidate it - this removes all data stored up to now 
        // (resets it to blank)
        HttpSession session = request.getSession();
        session.invalidate();
        logger.info("user logged out");
        // Send the user back to the login page
        forwardToJsp = "/Homepage.jsp";
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/Homepage.jsp";
             logger.warn("NumberFormatException occured in Logout Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Homepage.jsp";
            logger.warn("Null Point Exception occured in Logout Command");
            return forwardToJsp; 
        }
        
        
    }
}
    
