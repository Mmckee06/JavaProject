/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.User;
import Services.UserService;
import static command.LoginCommand.generateCSRFToken;
import java.math.BigInteger;
import java.net.URL;
import java.security.SecureRandom;
import java.util.Random;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class EditDetailsCommand implements Command  {
    private static final Logger logger = Logger.getLogger(EditDetailsCommand.class.getName());
    
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        HttpSession session = request.getSession();
        
    try {    
        //The user wants to Edit...
        String username = testImput(request.getParameter("Uname"));
       
        String LastName = testImput(request.getParameter("lname"));
        String FirstName = testImput(request.getParameter("fname"));
        String Address1 = testImput(request.getParameter("Address1"));
        String Address2 = testImput(request.getParameter("Address2"));
        String city = testImput(request.getParameter("city"));
        String pcode = testImput(request.getParameter("pcode"));
        String phone = testImput(request.getParameter("phone"));
        int user_Type = 0;
        String csrfToken = (String) request.getParameter("token");
        String storedToken = (String)session.getAttribute("csrfToken");
        
        //do check
       String csrfToken1 = org.apache.commons.lang3.StringUtils.substring(csrfToken, 0, 26);
       String storedToken1 = org.apache.commons.lang3.StringUtils.substring(storedToken, 0, 26);
        
        if (storedToken1.equals(csrfToken1)) {
               session.setAttribute("csrfToken", generateCSRFToken());
        
        if (username != null &&  LastName != null && FirstName != null && Address1 != null)
        {
            //Use the UserServive class to login...
            UserService userService = new UserService();
            User userEdit = userService.Edit(username,LastName,FirstName,Address1,Address2,city,pcode,phone,user_Type);

            if (userEdit != null)
            {
                forwardToJsp = "/Account.jsp";	
                logger.info(username + " changed details successfully");
            }
            else
            {
                forwardToJsp = "/changeInfo.jsp";
                logger.info(username + " changed details unsuccessfully as user is null");
            }
        }
        else 
        {
            forwardToJsp = "/changeInfo.jsp"; //Failed Login	
            logger.info(username + " changed details unsuccessfully as missing information");
        }
        
        return forwardToJsp;
        
        } else {
            forwardToJsp = "/Homepage.jsp";
            session.invalidate();
            return forwardToJsp;
        }
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/changeInfo.jsp";
             logger.warn("NumberFormatException occured in Edit Details Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/changeInfo.jsp";
            logger.warn("Null Point Exception occured in Edit Details Command");
            return forwardToJsp; 
        }
    }
    
    //sample implementation of token generation
public static String generateCSRFToken() {
   SecureRandom random = new SecureRandom();
   return new BigInteger(130, random).toString(32);
}
    
    public String testImput(String Input) {
        Input = Input.replace("&", "&amp;");
        Input = Input.replace("<", "&lt;");
        Input = Input.replace(">", "&gt;");
        Input = Input.replace("\"", "&quot;");
        Input = Input.replace("'", "&#x27;");
        Input = Input.replace("/", "&#x2F; ");
        return Input;
    }
  
}
    

