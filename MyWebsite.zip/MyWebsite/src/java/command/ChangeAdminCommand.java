/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.User;
import Services.UserService;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class ChangeAdminCommand implements Command {
    private static final Logger logger = Logger.getLogger(ChangeAdminCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
       try {  
        //The user wants to Register...
        String username = request.getParameter("Uname");
        
        
        if (username != null)
        {
            //Use the UserServive class to login...
            UserService userService = new UserService();
            User changeAdmin = userService.ChangeAdmin(username);
            logger.info(username + " is now an admin");

            if (changeAdmin != null)
            {
                forwardToJsp = "/UserActionServlet?action=ListUsers";	//Logged in			
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=ListUsers";	//Failed Login
            }
        }
        else 
        {
            logger.warn("Username not Found");
            forwardToJsp = "/UserActionServlet?action=ListUsers"; //Failed Login	
        }
        
        return forwardToJsp;
        
        }   catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=ListUsers";
            logger.warn("NumberFormatException occured in Change Admin");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=ListUsers";
            logger.warn("Null Point Exception occured in Change Admin");
            return forwardToJsp; 
        }
       
    }
}
