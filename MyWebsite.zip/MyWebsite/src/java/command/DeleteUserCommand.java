/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.User;
import Services.UserService;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class DeleteUserCommand implements Command{
    private static final Logger logger = Logger.getLogger(DeleteUserCommand.class.getName());
    
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
       
        String username = request.getParameter("Uname");
        
        
        if (username != null)
        {
            //Use the UserServive class to login...
            UserService userService = new UserService();
            User DeleteUser = userService.DeleteUser(username);
            
            if (DeleteUser != null)
            {
                forwardToJsp = "/UserActionServlet?action=ListUsers";	
                logger.info("User deleted by Admin" + username);
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=ListUsers";	
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=ListUsers"; 
            logger.info("Username not found to delete " + username);
        }
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=ListUsers";
            logger.warn("NumberFormatException occured in Delete User Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=ListUsers";
            logger.warn("Null Point Exception occured in Delete User Command");
            return forwardToJsp; 
        }
    }
}
    

