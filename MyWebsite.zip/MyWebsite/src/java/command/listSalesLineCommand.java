/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.Product_Order;
import Services.Product_OrderService;
import java.net.URL;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class listSalesLineCommand implements Command {
    private static final Logger logger = Logger.getLogger(listSalesLineCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        //Check to see if the session id coming from the client matches the id stored at login...
        HttpSession session = request.getSession();
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        //User not logged in...
        if ( session.getId() != session.getAttribute("loggedSessionId") )
        {
            forwardToJsp = "/Homepage.jsp";
            logger.info("Session expired");
        }
        else
        {	
            Product_OrderService orderService = new Product_OrderService();
            //Make the call to the 'Model' by using the UserService class to get all Users...
            List<Product_Order> products = orderService.getAllProducts();
            //Put the list of users into the session so that JSP(the View) can pick them up & display them...
            session.setAttribute("products", products);
            forwardToJsp = "/AdminSalesLine.jsp";
            logger.info("Sales Lines displayed correctly (Admin)");
        }
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/AdminSalesLine.jsp";
            logger.warn("NumberFormatException occured in List Sales Line Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/AdminSalesLine.jsp";
            logger.warn("Null Point Exception occured in List Sales Line Command");
            return forwardToJsp; 
        }
    }
    
}
