/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.User;
import Services.UserService;
import static command.AddToBasketCommand.generateCSRFToken;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class DeleteUser1Command implements Command{
    private static final Logger logger = Logger.getLogger(DeleteUser1Command.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
       try { 
        //The user wants to Register...
        HttpSession session = request.getSession();
        String username = testImput(request.getParameter("Uname"));
        String csrfToken = (String) request.getParameter("token");
        String storedToken = (String)session.getAttribute("csrfToken");
        
        //do check
       String csrfToken1 = org.apache.commons.lang3.StringUtils.substring(csrfToken, 0, 26);
       String storedToken1 = org.apache.commons.lang3.StringUtils.substring(storedToken, 0, 26);
       
       if (storedToken1.equals(csrfToken1)) {
               session.setAttribute("csrfToken", generateCSRFToken());
        
        if (username != null)
        {
            //Use the UserServive class to login...
            UserService userService = new UserService();
            User DeleteUser = userService.DeleteUser(username);
            session.invalidate();
            
            logger.info("User deleted" + username);
            if (DeleteUser != null)
            {
                forwardToJsp = "/Homepage.jsp";	//Sucess
                
            }
            else
            {
                forwardToJsp = "/Homepage.jsp";	//
            }
        }
        else 
        {
            forwardToJsp = "/Homepage.jsp"; //	
            logger.info("Username not found to delete " + username);
        }
        
        return forwardToJsp;
        
        } else {
            forwardToJsp = "/Homepage.jsp";
            session.invalidate();
            return forwardToJsp;
        }
        
        }   catch(NumberFormatException e) {
            forwardToJsp = "/Homepage.jsp";
            logger.warn("NumberFormatException occured in Delete User 1 Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Homepage.jsp";
            logger.warn("Null Point Exception occured in Delete User 1 Command");
            return forwardToJsp; 
        }
    }
    
    public String testImput(String Input) {
        Input = Input.replace("&", "&amp;");
        Input = Input.replace("<", "&lt;");
        Input = Input.replace(">", "&gt;");
        Input = Input.replace("\"", "&quot;");
        Input = Input.replace("'", "&#x27;");
        Input = Input.replace("/", "&#x2F; ");
        return Input;
    }
}
