/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

/**
 *
 * @author Michael
 */


import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import JavaClasses.User;
import Services.UserService;
import java.net.URL;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;


public class listUsersCommand implements Command 
{
    static final Logger logger = Logger.getLogger(listUsersCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        //Check to see if the session id coming from the client matches the id stored at login...
        HttpSession session = request.getSession();
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        //User not logged in...
        if ( session.getId() != session.getAttribute("loggedSessionId") )
        {
            forwardToJsp = "/Homepage.jsp";
            logger.info("Session expired");
        }
        else
        {	
            UserService userService = new UserService();
            //Make the call to the 'Model' by using the UserService class to get all Users...
            List<User> users = userService.getAllUsers();
            //Put the list of users into the session so that JSP(the View) can pick them up & display them...
            session.setAttribute("users", users);
            forwardToJsp = "/Admin.jsp";
            logger.info("Users listed Sucessfully (Admin)");
        }
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/Admin.jsp";
            logger.warn("NumberFormatException occured in List Users Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Admin.jsp";
            logger.warn("Null Point Exception occured in List Users Command");
            return forwardToJsp; 
        }
    }
}