/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.PremTable;
import Services.TableService;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class addTeamCommand implements Command {
    private static final Logger logger = Logger.getLogger(addTeamCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
    try {    
        int pos = Integer.parseInt(request.getParameter("position"));
        String teamname = request.getParameter("teamName");
        int GamesPlayed = Integer.parseInt(request.getParameter("GamesPlayed"));
        int GoalsFor = Integer.parseInt(request.getParameter("GoalsFor"));
        int GoalsAgainst = Integer.parseInt(request.getParameter("GoalsAgainst"));
        int GoalDifference = Integer.parseInt(request.getParameter("GoalDifference"));
        int points = Integer.parseInt(request.getParameter("points"));
        
        
        if (teamname != null)
        {
            //Use the UserServive class to login...
            TableService TableService = new TableService();
            PremTable addItem1 = TableService.addItem(pos, teamname, GamesPlayed, GoalsFor, GoalsAgainst, GoalDifference, points);

            if (addItem1 != null)
            {
                logger.info(teamname + " added successfully");
                forwardToJsp = "/UserActionServlet?action=List Teams1";				
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=List Teams1";	
                logger.info("Team " + teamname + " not added");
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=List Teams1"; 
            logger.info("Tteam not added due to missing information");
        }
        
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=List Teams1";
            logger.warn("NumberFormatException occured in add team Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=List Teams1";
            logger.warn("Null Point Exception occured in add team Command");
            return forwardToJsp; 
        }
    } 
    
}
