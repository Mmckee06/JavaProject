/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import JavaClasses.News;
import Services.newsService;
import java.net.URL;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
/**
 *
 * @author Michael
 */
public class listNewsCommand implements Command 
{
    private static final Logger logger = Logger.getLogger(listNewsCommand.class.getName());
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        //Check to see if the session id coming from the client matches the id stored at login...
        HttpSession session = request.getSession();
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        //User not logged in...
        if ( session.getId() != session.getAttribute("loggedSessionId") )
        {
            forwardToJsp = "/Homepage.jsp";
            logger.info("Session expired");
        }
        else
        {	
            newsService newsService = new newsService();
            //Make the call to the 'Model' by using the UserService class to get all Users...
            List<News> news = newsService.getAllNews();
            //Put the list of users into the session so that JSP(the View) can pick them up & display them...
            session.setAttribute("news", news);
            forwardToJsp = "/AdminNews.jsp";
            logger.info("News listed successfully (Admin)");
        }
        return forwardToJsp;
        
        } catch(NumberFormatException e) {
            forwardToJsp = "/AdminNews.jsp";
            logger.warn("NumberFormatException occured in List news Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/AdminNews.jsp";
            logger.warn("Null Point Exception occured in List news Command");
            return forwardToJsp; 
        }
    }
}
    

