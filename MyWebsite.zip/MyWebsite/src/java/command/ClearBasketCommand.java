/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

/**
 *
 * @author Michael
 */
import JavaClasses.Store;
import Services.StoreService;

import java.net.URL;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class ClearBasketCommand implements Command  {
    //ArrayList<Store>  SessionItems = new ArrayList<Store>();
    private static final Logger logger = Logger.getLogger(ClearBasketCommand.class.getName());
    
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
       
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
     try {   
        
        //The user wants to Rremove Item...
        
            HttpSession session = request.getSession();
           ArrayList basket = (ArrayList)session.getAttribute("basket");
            //session.setAttribute("basket",SessionItems);
                
            if (basket != null)
            {
                //SessionItems.add(addItem1);
                basket.removeAll(basket);
                forwardToJsp = "/Basket.jsp";				
                logger.info("All items in basket removed");
            return forwardToJsp;
    
           } else {
                forwardToJsp = "/Basket.jsp";
                logger.info("Nothing in basket to remove");
               return forwardToJsp; 
            }
            
        }   catch(NumberFormatException e) {
            forwardToJsp = "/Basket.jsp";
            logger.warn("NumberFormatException occured in Clear Basket Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Basket.jsp";
            logger.warn("Null Point Exception occured in Clear Basket Command");
            return forwardToJsp; 
        }
    }
}

