/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import ActionServet.UserActionServlet;
import DAO.MyDatasource;
import DAO.googleAuthDAO;
import Exceptions.DaoException;
import JavaClasses.User;
import JavaClasses.googleAuth;
import Services.UserService;
import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.junit.BeforeClass;
/**
 *
 * @author Michael
 */
public class createGoogleAuthCommand implements Command{
   private static final Logger logger = Logger.getLogger(createGoogleAuthCommand.class.getName()); 
public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
   try {     
           HttpSession session = request.getSession(); 
           User user = (User)session.getAttribute("user");
           
            int code = (int) session.getAttribute("authCode");
            if (code == 1) { 
                forwardToJsp = "account.jsp"; 
            } else { 
                GoogleAuthenticator googleAuthenticator = new GoogleAuthenticator();
                
        final GoogleAuthenticatorKey key = googleAuthenticator.createCredentials(user.getUsername()); 
        final String secretKey = key.getKey(); 
        final List<Integer> scratchCodes = key.getScratchCodes();
        
        String urlImage = GoogleAuthenticatorKey.getQRBarcodeURL(user.getUsername(), "footyWebsite", secretKey);
        
        session.setAttribute("KeyImage", urlImage); 
        session.setAttribute("secretKey", secretKey); 
        
        
        googleAuthDAO dao = new googleAuthDAO(new MyDatasource());
        googleAuth a = new googleAuth(user.getUsername(),secretKey);
                    
           dao.addKey(a);  
           user.setGoogleAuth(1);
         forwardToJsp = "googleAuth.jsp";            
         
                    
       for (Integer i : scratchCodes) { 
        //if (!googleAuthenticator.validateScratchCode(i)) { 
            //throw new IllegalArgumentException("An invalid code has been " + "generated: this is an application bug.");
       }}
        
   
        return forwardToJsp;
    
        } catch(NumberFormatException e) {
            forwardToJsp = "/Register.jsp";
            logger.warn("NumberFormatException occured in Register Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Register.jsp";
            logger.warn("Null Point Exception occured in Register Command");
            return forwardToJsp; 
        } catch (DaoException ex) {
           java.util.logging.Logger.getLogger(createGoogleAuthCommand.class.getName()).log(Level.SEVERE, null, ex);
       }
       return null;
      
}
}

