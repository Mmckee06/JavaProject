/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

/**
 *
 * @author Michael
 */
public class CommandFactory {

    private static CommandFactory factory = null;
    
    private CommandFactory() {
    }
	
    public static synchronized CommandFactory getInstance()
    {
        if(factory == null)
        {
            factory = new CommandFactory();
        }
        return factory;
    }
    
    public synchronized Command createCommand(String commandStr) 
    {
    	Command command = null;
    	
	//Instantiate the required Command object...
    	if (commandStr.equals("login")) {
    		command = new LoginCommand();
    	}
    	if (commandStr.equals("logout")) {
    		command = new LogoutCommand();
    	}
        if (commandStr.equals("Register")) {
    		command = new RegisterCommand();
    	}
        if (commandStr.equals("ListUsers")) {
    		command = new listUsersCommand();
    	}
        if (commandStr.equals("Change Details")) {
    		command = new EditDetailsCommand();
    	}
        if (commandStr.equals("Change Password")) {
    		command = new ChangePasswordCommand();
    	}
        if (commandStr.equals("Change Admin")) {
    		command = new ChangeAdminCommand();
    	}
        if (commandStr.equals("Delete User")) {
    		command = new DeleteUserCommand();
    	}
        if (commandStr.equals("List Items")) {
    		command = new ListItemsCommand();
    	}
        if (commandStr.equals("add Item")) {
    		command = new addItemCommand();
    	}
        if (commandStr.equals("Delete Item")) {
    		command = new DeleteItemCommand();
    	}
        if (commandStr.equals("Edit Item")) {
    		command = new EditItemCommand();
    	}
        if (commandStr.equals("Add to Basket")) {
    		command = new AddToBasketCommand();
    	}
        if (commandStr.equals("Store")) {
    		command = new ListStoreCommand();
    	}
         if (commandStr.equals("List Teams")) {
    		command = new ListTeamsCommand();
    	}
         if (commandStr.equals("Delete My Account")) {
    		command = new DeleteUser1Command();
    	}
         if (commandStr.equals("List Teams1")) {
    		command = new ListTeamsAdminCommand();
    	}
         if (commandStr.equals("Update Team")) {
    		command = new UpdateTableCommand();
    	}
         if (commandStr.equals("Add Team")) {
    		command = new addTeamCommand();
    	}
         if (commandStr.equals("Delete Team")) {
    		command = new DeleteTeamCommand();
    	}
         if (commandStr.equals("Change Password of User")) {
    		command = new ChangePassword1Command();
    	}
         if (commandStr.equals("Remove")) {
    		command = new RemoveFromBasketCommand();
    	}
         if (commandStr.equals("Remove All")) {
    		command = new ClearBasketCommand();
    	}
         if (commandStr.equals("Buy Items")) {
    		command = new ItemsBoughtCommand();
    	}
         if (commandStr.equals("List Orders")) {
    		command = new ListOrdersCommand();
    	}
         if (commandStr.equals("Delete Sale")) {
    		command = new DeleteSaleCommand();
    	}
         if (commandStr.equals("List Products")) {
    		command = new listSalesLineCommand();
    	}
         if (commandStr.equals("List News")) {
    		command = new listNewsCommand();
    	}
         if (commandStr.equals("List Cust Sales")) {
    		command = new ListCustomersOrdersCommand();
    	}
         if (commandStr.equals("Add Discount")) {
    		command = new AddDiscountCommand();
    	} 
         if (commandStr.equals("Turn off Google Authenticator")) {
    		command = new TurnofGoogleCommand();
    	}
         if (commandStr.equals("List Google Auth")) {
    		command = new ListGoogleAuthCommand();
    	}
         if (commandStr.equals("Delete Google Auth")) {
    		command = new deleteAuthCommand();
    	}
         if (commandStr.equals("Turn off User Authenticator")) {
    		command = new deleteAuthCommand();
    	}
         
         
         
          
    	//Return the instantiated Command object to the calling code...
    	return command;// may be null
    }    
}
