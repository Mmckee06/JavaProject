/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.PremTable;
import Services.TableService;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class DeleteTeamCommand implements Command{
    private static final Logger logger = Logger.getLogger(DeleteTeamCommand.class.getName());
    
     public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        //The user wants to Delete...
        String teamname = request.getParameter("teamName");
        
        
        if (teamname != null )
        {
            //Use the UserServive class to login...
            TableService TableService = new TableService();
            PremTable Deleteteam = TableService.DeleteTeam(teamname);

            if (Deleteteam != null)
            {
                forwardToJsp = "/UserActionServlet?action=List Teams1";	
                logger.info("Team deleted " + teamname);
            }
            else
            {
                forwardToJsp = "/UserActionServlet?action=List Teams1";	
                logger.info("Team Name not found to delete " + teamname);
            }
        }
        else 
        {
            forwardToJsp = "/UserActionServlet?action=List Teams1"; 
            logger.info("Team Name not found to delete (missing info) " + teamname);
        }
        
        return forwardToJsp;
        
        }   catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=List Teams1";
            logger.warn("NumberFormatException occured in Delete Team Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=List Teams1";
            logger.warn("Null Point Exception occured in Delete Team Command");
            return forwardToJsp; 
        }
    }
     
    
}
