/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

/**
 *
 * @author Michael
 */
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import JavaClasses.User;
import Services.UserService;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
/**
 *
 * @author Michael
 */
public class ChangePassword1Command implements Command  {
    private static final Logger logger = Logger.getLogger(ChangePassword1Command.class.getName());
    
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
      try {  
        //The user wants to Register...
        String username = request.getParameter("Uname");
        String OldPassword = request.getParameter("OldPassword");
        String NewPassword = request.getParameter("NewPassword");
        
        
        if (username != null && OldPassword != null && NewPassword != null)
        {
            //Use the UserServive class to login...
            UserService userService = new UserService();
            User changePassword = userService.ChangePassword(username,OldPassword,NewPassword);

            if (changePassword != null)
            {
                logger.info("Password changed successfully");
                forwardToJsp = "/UserActionServlet?action=ListUsers";	//Logged in			
            }
            else
            {
                logger.info("Password not changed");
                forwardToJsp = "/UserActionServlet?action=ListUsers";	//Failed Login
            }
        }
        else 
        {
            logger.warn("Missing Information");
            forwardToJsp = "/UserActionServlet?action=ListUsers"; //Failed Login	
        }
        
        return forwardToJsp;
        
        }   catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=ListUsers";
            logger.warn("NumberFormatEexception in Change password Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=ListUsers";
            logger.warn("Null Point Exception occured in Change Password Command");
            return forwardToJsp; 
        }
    }
}
 
