/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.Store;
import Services.StoreService;
import java.net.URL;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class RemoveFromBasketCommand implements Command  {
    //ArrayList<Store>  SessionItems = new ArrayList<Store>();
    private static final Logger logger = Logger.getLogger(RemoveFromBasketCommand.class.getName());
    
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
       
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try {
        
        //The user wants to Rremove Item...
        
            HttpSession session = request.getSession();
            StoreService storeService = new StoreService();
             int id = Integer.parseInt(request.getParameter("ID1"));
             
             ArrayList <Store> basket = (ArrayList)session.getAttribute("basket");
             //Store removeItem1 = storeService.findItemforArrayList(id);
            //session.setAttribute("basket",SessionItems);
             //removeItem1.addQuantity(1);   
            if (basket != null)
            {
                //SessionItems.add(addItem1);
                
               
               if(basket.get(id).getQuantity() > 1){
                 basket.get(id).SubQuantityBasket(1);
                 logger.info("Item quantity decrased by 1");
               }
               if(basket.get(id).CheckifNull() == true){
                  basket.remove(id);  
                  logger.info("Item totally removed from basket");
               }
                
               
                   
                forwardToJsp = "/Basket.jsp";				
            
            return forwardToJsp;
    
           } else {
                forwardToJsp = "/Basket.jsp";
                
               return forwardToJsp; 
            }
            
            } catch(NumberFormatException e) {
            forwardToJsp = "/Basket.jsp";
            logger.warn("NumberFormatException occured in Remove from basket Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Basket.jsp";
            logger.warn("Null Point Exception occured in Remove from basket Command");
            return forwardToJsp; 
        }
            
}
    
    

}