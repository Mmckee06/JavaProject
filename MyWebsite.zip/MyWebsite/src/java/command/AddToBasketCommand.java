/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import JavaClasses.Store;
import Services.StoreService;
import static command.EditDetailsCommand.generateCSRFToken;
import java.math.BigInteger;
import java.net.URL;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.logging.LogManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author Michael
 */
public class AddToBasketCommand implements Command  {
    //ArrayList<Store>  SessionItems = new ArrayList<Store>();
    private static final Logger logger = Logger.getLogger(AddToBasketCommand.class.getName());

    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
        try{
  
        int quantity = Integer.parseInt(request.getParameter("quantity"));
   
        //The user wants to add Item...
        
           HttpSession session = request.getSession();
            StoreService storeService = new StoreService();
             int id = Integer.parseInt(request.getParameter("ID1"));
             Store addItem1 = storeService.findItemforArrayList(id,quantity); 
             String csrfToken = (String) request.getParameter("token");
        String storedToken = (String)session.getAttribute("csrfToken");
        
        //do check
       String csrfToken1 = org.apache.commons.lang3.StringUtils.substring(csrfToken, 0, 26);
       String storedToken1 = org.apache.commons.lang3.StringUtils.substring(storedToken, 0, 26);
             
             
             
             ArrayList <Store> basket = (ArrayList)session.getAttribute("basket");
             
             if (storedToken1.equals(csrfToken1)) {
               session.setAttribute("csrfToken", generateCSRFToken());
             if (addItem1 != null)
            {
                //SessionItems.add(addItem1);
                for (int i=0; i< basket.size();i++) {
                    if (basket.get(i).getItemName().equals(addItem1.getItemName())){ 
                        //basket.get(i).addQuantityBasket(basket.get(i).getQuatityBasket());
                         addItem1.addQuantityBasket(basket.get(i).getQuatityBasket());
                         logger.info("Same item already in basket");
                     //basket.remove(addItem1); 
                         basket.remove(basket.get(i));
                         
            } 
                }     
                
                
                addItem1.addQuantityBasket(quantity -1);
                
                
                     basket.add(addItem1); 
                logger.info("New Item " + addItem1.getItemName() + " added to basket");
                
             
                forwardToJsp = "/UserActionServlet?action=Store";
            
            return forwardToJsp;
    
           } else {
                forwardToJsp = "/UserActionServlet?action=Store";
                logger.warn("Item not added");
                
               return forwardToJsp; 
            }
             
             } else {
            forwardToJsp = "/Homepage.jsp";
            session.invalidate();
            return forwardToJsp;
        }
             
       }   catch(NumberFormatException e) {
            forwardToJsp = "/UserActionServlet?action=Store";
            logger.warn("NumberFormatException occured in Add Basket");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/UserActionServlet?action=Store";
            logger.warn("Null Point Exception occured in Add Basket");
            return forwardToJsp; 
        }
       
                  
}
    
      //sample implementation of token generation
public static String generateCSRFToken() {
   SecureRandom random = new SecureRandom();
   return new BigInteger(130, random).toString(32);
}


        
    
    

}
