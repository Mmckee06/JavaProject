/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package command;

import Services.StoreService;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import JavaClasses.Sales_Order;
import Services.Sales_OrderService;
import JavaClasses.Product_Order;
import Services.Product_OrderService;
import JavaClasses.Store;
import JavaClasses.User;
import java.net.URL;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;


/**
 *
 * @author Michael
 */
public class ItemsBoughtCommand implements Command  {
    //ArrayList<Store>  SessionItems = new ArrayList<Store>();
    private static final Logger logger = Logger.getLogger(ItemsBoughtCommand.class.getName());
    
    public String execute(HttpServletRequest request, HttpServletResponse response) 
    {
       
        String forwardToJsp;
        
        URL u = getClass().getClassLoader().getResource("/log4j.xml");
        DOMConfigurator.configure(u);
        
      try { 
        
            HttpSession session = request.getSession();
           ArrayList <Store> basket = (ArrayList)session.getAttribute("basket");
           User user = (User)session.getAttribute("user");
            double total = (Double)session.getAttribute("basketPrice");
            int totalItems = (Integer)session.getAttribute("basketTotal");
            //session.setAttribute("basket",SessionItems);
            
                
            if (basket != null)
            {
                //SessionItems.add(addItem1);
                Sales_OrderService Sales_OrderService = new Sales_OrderService();
                Product_OrderService Product_OrderService = new Product_OrderService(); 
             
                Sales_Order addSale1 = Sales_OrderService.addOrder(user.getCusomerId(),totalItems,total); 
                
                Sales_OrderService SalesService = new Sales_OrderService();
                Sales_Order s1 = SalesService.FindOrderForID(addSale1.getCustID(),addSale1.getTotalItems(),addSale1.getTotal());
                
                int ID =  s1.getSalesId();
                
                
                
                for (int i =0;i<basket.size();i++) {
                   Product_Order addProduct = Product_OrderService.addProduct(ID, basket.get(i).getItemID(),basket.get(i).getQuatityBasket());
                }
            
                logger.info("Items bought by Customer " + user.getUsername());
                forwardToJsp = "/UserActionServlet?action=List Cust Sales";				
                basket.removeAll(basket);
                return forwardToJsp;
    
           } else {
                forwardToJsp = "/BoughtItems.jsp";
                logger.info("Nothing in basket to buy");
                
               return forwardToJsp; 
            }
            
            } catch(NumberFormatException e) {
            forwardToJsp = "/BoughtItems.jsp";
            logger.warn("NumberFormatException occured in Item Bought Command");
            return forwardToJsp; 
        } catch(NullPointerException e) {
            forwardToJsp = "/BoughtItems.jsp";
            logger.warn("Null Point Exception occured in Item Bought Command");
            return forwardToJsp; 
        }
    }
}
    

