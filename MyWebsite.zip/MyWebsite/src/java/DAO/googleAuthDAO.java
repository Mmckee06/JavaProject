/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import Exceptions.DaoException;
import JavaClasses.googleAuth;
import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Michael
 */
public class googleAuthDAO extends Dao {
     static Logger logger = Logger.getLogger(googleAuthDAO.class.getName());
    
    public googleAuthDAO(DataSource ds)
{
	super(ds);
}
    
    public List<googleAuth> findAllAuths() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<googleAuth> auths = new ArrayList<googleAuth>();
        try {
            con = this.getConnection();

            String query = "SELECT * FROM googleAuth";
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            while (rs.next()) {
                int ID = rs.getInt("authID");
                String username = rs.getString("Username");
                String Key = rs.getString("SecretKey");
                
                googleAuth s = new googleAuth(ID,username,Key);
                
                auths.add(s);
            }
        } catch (SQLException e) {
            logger.warn("List all Keys SQL Exception (DAO)");
            throw new DaoException("findAllItems() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("List all Keys SQL Exception (DAO)");
                throw new DaoException(e.getMessage());
            }
        }
        return auths;     // may be empty
    }
    
    public int addKey(googleAuth u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            
            String query = "SELECT authID FROM googleAuth WHERE username= ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, u.getAuthID());

            rs = ps.executeQuery();
            //if (rs.next()) {
                //throw new DaoException("ITEMNAME " + u.getAuthID() + " already exists");
            //} 

            String command = "INSERT INTO GoogleAuth (authID, username, secretKey) VALUES(?, ?, ?)";
            ps = con.prepareStatement(command);
            ps.setInt(1, u.getAuthID());
            ps.setString(2, u.getUsername());
            ps.setString(3, u.getKey());
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Add Key SQL Exception (DAO)");
            throw new DaoException("addItem: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Add Key SQL Exception (DAO)");
                throw new DaoException("addItem(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    public googleAuth findAuthByUsername(String uname) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        googleAuth u = null;
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM GoogleAuth WHERE USERNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, uname);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                logger.info("Users Secret Key found");
                int ID = rs.getInt("AuthID");
                String username = rs.getString("Username");
                String Key = rs.getString("SecretKey");
                
                u = new googleAuth(ID,username,Key);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find User by username and password SQL Exception (DAO)");
            throw new DaoException("findUsersByUsernamePassword " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find User by username and password SQL Exception (DAO)");
                throw new DaoException("findUsersByUsernamePassword" + e.getMessage());
            }
        }
       
        return u;
        // p may be null 
    }
    
     public int deleteAuthByID(int ID) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();

            String command = "DELETE FROM GoogleAuth WHERE authID =?" ;
            ps = con.prepareStatement(command);
            ps.setInt(1,ID);
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Delete Sales Order SQL Exception (DAO)");
            throw new DaoException("deleteProductBySalesID: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Delete Google Auth SQL Exception (DAO)");
                throw new DaoException("deleteAuthByID(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
     
     public googleAuth findAuthByID(int ID1) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        googleAuth u = null;
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM GoogleAuth WHERE authID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, ID1);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                logger.info("Users Secret Key found");
                int ID = rs.getInt("AuthID");
                String username = rs.getString("Username");
                String Key = rs.getString("SecretKey");
                
                u = new googleAuth(ID,username,Key);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find User by username and password SQL Exception (DAO)");
            throw new DaoException("findUsersByUsernamePassword " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find User by username and password SQL Exception (DAO)");
                throw new DaoException("findUsersByUsernamePassword" + e.getMessage());
            }
        }
       
        return u;
        // p may be null 
    }
    
    
    
    
   
 }
    
 