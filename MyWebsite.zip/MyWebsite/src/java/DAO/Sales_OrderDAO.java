/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import JavaClasses.Sales_Order;
import Exceptions.DaoException;
import java.util.Properties;

import javax.sql.DataSource;
import org.apache.log4j.Logger;
/**
 * Provides all the functionality needed for the sales_order table. This includes thing like getting data
 * from this database, updating the database or deleting.
 * @author Michael
 */
public class Sales_OrderDAO extends Dao {
    
    static Logger logger = Logger.getLogger(Sales_OrderDAO.class.getName());
    Properties props = new Properties();
    
    public Sales_OrderDAO(DataSource ds)
    {
	super(ds);  //super() calls the parent constructor
    }
    
    //Function to list all orders in database
    public List<Sales_Order> findAllOrders() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Sales_Order> orders = new ArrayList<Sales_Order>();
        try {
            con = this.getConnection();

            String query = "SELECT * FROM Sales_Order";
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            while (rs.next()) {
                int SalesID = rs.getInt("SalesID");
                int custID = rs.getInt("CUSTOMERID");
                int totalItems = rs.getInt("TotalItems");
                double total = rs.getDouble("Total");
                
                 Sales_Order s = new Sales_Order(SalesID, custID, totalItems, total);
                
                orders.add(s);
            }
        } catch (SQLException e) {
            logger.warn("List Sales Orders SQL Exception (DAO)");
            throw new DaoException("findAllItems() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("List Sales Orders SQL Exception (DAO)");
                throw new DaoException(e.getMessage());
            }
        }
        return orders;     // may be empty
    }
    
    //List all orders by customer ID, will return all users orders
    public List<Sales_Order> findAllOrdersByCustID(int CustID) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Sales_Order> orders = new ArrayList<Sales_Order>();
        try {
            con = this.getConnection();

            String query = "SELECT * FROM Sales_Order WHERE CUSTOMERID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, CustID);
            
            rs = ps.executeQuery();
            while (rs.next()) {
                int SalesID = rs.getInt("SalesID");
                int custID = rs.getInt("CUSTOMERID");
                int totalItems = rs.getInt("TotalItems");
                double total = rs.getDouble("Total");
                
                 Sales_Order s = new Sales_Order(SalesID, custID, totalItems, total);
                
                orders.add(s);
            }
        } catch (SQLException e) {
            logger.warn("List Sales Orders by Sales ID SQL Exception (DAO)");
            throw new DaoException("findAllItemsByCustID() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("List Sales Orders by Sales ID SQL Exception (DAO)");
                throw new DaoException(e.getMessage());
            }
        }
        return orders;     // may be empty
    }
    
    //Function to add a new order
    public int addOrder(Sales_Order u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            
            String query = "SELECT SalesID FROM Sales_Order WHERE SalesID= ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, u.getSalesId());

            rs = ps.executeQuery();
            if (rs.next()) {
                logger.warn("Sales Already Exists (DAO)");
                throw new DaoException("SalesID " + u.getSalesId() + " already exists");
            } 

            String command = "INSERT INTO Sales_Order (SalesID, CUSTOMERID, TotalItems, Total ) VALUES(?, ?, ?, ?)";
            ps = con.prepareStatement(command);
            ps.setInt(1, u.getSalesId());
            ps.setInt(2, u.getCustID());
            ps.setInt(3, u.getTotalItems());
            ps.setDouble(4, u.getTotal());
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Add Sales Order SQL Exception (DAO)");
            throw new DaoException("addSale " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Add Sales Order SQL Exception (DAO)");
                throw new DaoException("addSale(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Function to find item by Sales ID
     public Sales_Order findItemsBySalesID(int ID) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Sales_Order u = null;
        
        
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM Sales_Order WHERE SalesID= ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, ID);
            
            
            rs = ps.executeQuery();
            if (rs.next()) {
                int SalesID = rs.getInt("SalesID");
                int CustID = rs.getInt("CUSTOMERID");
                int TotalItems = rs.getInt("TotalItems");
                double total =rs.getInt("Total");
                
                
                u = new Sales_Order(SalesID,CustID,TotalItems,total);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find Sales Order by ID SQL Exception (DAO)");
            throw new DaoException("findOrderbyID " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find Sales Order by ID SQL Exception (DAO)");
                throw new DaoException("findOrderbyID" + e.getMessage());
            }
        }
        return u;
    }
     
     //Find an item by customer ID, total items and total
      public Sales_Order findItemsForSalesID(int CusID,int totalItems,double total1) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Sales_Order u = null;
        
        
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM Sales_Order WHERE CUSTOMERID = ? AND TotalItems = ? AND Total = ? ORDER BY SalesID DESC ";
            ps = con.prepareStatement(query);
            ps.setInt(1, CusID);
            ps.setInt(2, totalItems);
            ps.setDouble(3,total1);
           
            rs = ps.executeQuery();
            if (rs.next()) {
                int SalesID = rs.getInt("SalesID");
                int CustID = rs.getInt("CUSTOMERID");
                int TotalItems = rs.getInt("TotalItems");
                double total =rs.getInt("Total");
                
                
                u = new Sales_Order(SalesID,CustID,TotalItems,total);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find tems for Sales Order by ID SQL Exception (DAO)");
            throw new DaoException("findOrderbyID " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find tems for Sales Order by ID SQL Exception (DAO)");
                throw new DaoException("findOrderbyID" + e.getMessage());
            }
        }
        return u;
    }
      
      //Find an order by a customer ID
      public Sales_Order findOrderByCustID(int ID) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Sales_Order u = null;
        
        
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM Sales_Order WHERE CUSTOMERID = ? ORDER BY SalesID DESC ";
            ps = con.prepareStatement(query);
            ps.setInt(1, ID);
            
            
            rs = ps.executeQuery();
            if (rs.next()) {
                int SalesID = rs.getInt("SalesID");
                int CustID = rs.getInt("CUSTOMERID");
                int TotalItems = rs.getInt("TotalItems");
                double total =rs.getInt("Total");
                
                
                u = new Sales_Order(SalesID,CustID,TotalItems,total);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find Order by CUSTID SQL Exception (DAO)");
            throw new DaoException("findOrderbyID " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find Order by CUSTID SQL Exception (DAO)");
                throw new DaoException("findOrderbyID" + e.getMessage());
            }
        }
        return u;
    }
      
      //Funtion to remove sales order by sales ID
        public int deleteSaleBySalesID(int SalesID) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();

            String command = "DELETE FROM Sales_Order WHERE SalesID =?" ;
            ps = con.prepareStatement(command);
            ps.setInt(1,SalesID);
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Delete Sales Order SQL Exception (DAO)");
            throw new DaoException("deleteProductBySalesID: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Delete Sales Order SQL Exception (DAO)");
                throw new DaoException("deleteProductBySalesID(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
}

