/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

/**
 *
 * @author Michael
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import JavaClasses.News;
import Exceptions.DaoException;
import java.util.Properties;

import javax.sql.DataSource;
import org.apache.log4j.Logger;
/**
 *
 * @author Michael
 */
public class newsDAO extends Dao {
    
    static Logger logger = Logger.getLogger(newsDAO.class.getName());
    
    
    public newsDAO(DataSource ds)
    {
	super(ds);
    }
    
    public List<News> findAllNews() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<News> news = new ArrayList<News>();
        try {
            con = this.getConnection();

            String query = "SELECT * FROM news ORDER BY id DESC ";
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            while (rs.next()) {
                int newsID = rs.getInt("id");
                String des= rs.getString("description");
                
                
                 News s = new News(newsID,des);
                
                news.add(s);
            }
        } catch (SQLException e) {
            logger.warn("News listed SQL Exception (DAO)");
            throw new DaoException("findAllItems() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("News listed SQL Exception (DAO)");
                throw new DaoException(e.getMessage());
            }
        }
        return news;     // may be empty
    }
}