/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import JavaClasses.User;
import Exceptions.DaoException;
import java.util.Properties;


/**
 *
 * @author mmckee
 */
import javax.sql.DataSource;
import org.apache.log4j.Logger;

public class UserDAO extends Dao {
    
    static Logger logger = Logger.getLogger(UserDAO.class.getName());
    
    
    public UserDAO(DataSource ds)
{
	super(ds); //super() calls the parent constructor
}

    //Lists all users in the customer database
    public List<User> findAllUsers() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<User> users = new ArrayList<User>();
        try {
            con = this.getConnection();

            String query = "SELECT * FROM customer";
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            while (rs.next()) {
                int CustId = rs.getInt("CUSTOMERID");
                String username = rs.getString("USERNAME");
                String password = rs.getString("PASSWORD");
                String lastname = rs.getString("LASTNAME");
                String firstname = rs.getString("FIRSTNAME");
                String AddressLine1 = rs.getString("AddressLine1");
                String AddressLine2 = rs.getString("AddressLine2");
                String CITY = rs.getString("CITY");
                String POSTALCODE = rs.getString("POSTALCODE");
                String PHONE = rs.getString("PHONE");
                int user_type = rs.getInt("user_Type");
                int auth = rs.getInt("googleAuth");
                
                User u = new User(CustId,username, password, lastname, firstname,AddressLine1,AddressLine2,CITY,POSTALCODE,PHONE,user_type,auth);
                users.add(u);
            }
        } catch (SQLException e) {
            logger.warn("Users listed SQL Exception (DAO)");
            throw new DaoException("findAllUsers() " + e.getMessage());
         } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Users listed SQL Exception (DAO)");
                throw new DaoException(e.getMessage());
            }
        }
        return users;     // may be empty
    }
    
    //Find a user in the database by username
    public User findUsersByUsername(String uname) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        User u = null;
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM customer WHERE USERNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, uname);
            
            
            rs = ps.executeQuery();
            if (rs.next()) {
                int CustId = rs.getInt("CUSTOMERID");
                String username = rs.getString("USERNAME");
                String password = rs.getString("PASSWORD");
                String lastname = rs.getString("LASTNAME");
                String firstname = rs.getString("FIRSTNAME");
                String AddressLine1 = rs.getString("AddressLine1");
                String AddressLine2 = rs.getString("AddressLine2");
                String CITY = rs.getString("CITY");
                String POSTALCODE = rs.getString("POSTALCODE");
                String PHONE = rs.getString("PHONE");
                int user_Type = rs.getInt("user_Type");
                int auth = rs.getInt("googleAuth");
                
                u = new User(CustId, username, password, lastname, firstname,AddressLine1,AddressLine2,CITY,POSTALCODE,PHONE,user_Type,auth);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find User by Username SQL Exception (DAO)");
            throw new DaoException("findUsersByUsername " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find User by Username SQL Exception (DAO)");
                throw new DaoException("findUsersByUsername" + e.getMessage());
            }
        }
       
        return u;
        // u may be null 
    }
    
    //Function for username to login, finds username and password
     public User findUsersByUsernamePassword(String uname, String upass) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        User u = null;
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM customer WHERE USERNAME = ? and PASSWORD = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, uname);
            ps.setString(2, upass);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                logger.info("User logged in Successfully");
                int CustId = rs.getInt("CUSTOMERID");
                String username = rs.getString("USERNAME");
                String password = rs.getString("PASSWORD");
                String lastname = rs.getString("LASTNAME");
                String firstname = rs.getString("FIRSTNAME");
                String AddressLine1 = rs.getString("AddressLine1");
                String AddressLine2 = rs.getString("AddressLine2");
                String CITY = rs.getString("CITY");
                String POSTALCODE = rs.getString("POSTALCODE");
                String PHONE = rs.getString("PHONE");
                int user_Type = rs.getInt("user_Type");
                int auth = rs.getInt("googleAuth");
                
                
                u = new User(CustId,username, password, lastname, firstname,AddressLine1,AddressLine2,CITY,POSTALCODE,PHONE,user_Type,auth);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find User by username and password SQL Exception (DAO)");
            throw new DaoException("findUsersByUsernamePassword " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find User by username and password SQL Exception (DAO)");
                throw new DaoException("findUsersByUsernamePassword" + e.getMessage());
            }
        }
       
        return u;
        // p may be null 
    }
     
     //Edits the users information
    public int amendUserNameAddress(User u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            String query = "SELECT CUSTOMERID, USERNAME FROM customer WHERE USERNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, u.getUsername());

            rs = ps.executeQuery();
            if (rs.next()) {
                String bId = rs.getString("USERNAME");
                //if (bId != u.getUsername())
                    //throw new DaoException("UserName " + u.getUsername() + " already exists for another customer");
            }

            String command = "UPDATE customer SET USERNAME = ?, PASSWORD=?, LASTNAME =?, FIRSTNAME =?, AddressLine1 =?, AddressLine2 =?, CITY=?, POSTALCODE=?, Phone=? WHERE USERNAME=?";
            ps = con.prepareStatement(command);
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getLastname());
            ps.setString(4,u.getFirstname());
            ps.setString(5, u.getAddressLine1());
            ps.setString(6, u.getAddressLine2());
            ps.setString(7, u.getCity());
            ps.setString(8, u.getPostalCode());
            ps.setString(9, u.getPhone());
            ps.setString(10, u.getUsername());                        
           
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Amend UsernameAdress SQL Exception (DAO)");
            throw new DaoException("amendUser: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Amend UsernameAdress SQL Exception (DAO)");
                throw new DaoException("amendUser(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Edit the users contact number
    public int amendContactNumber(User u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            String query = "SELECT CUSTOMERID, USERNAME FROM customer WHERE USERNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, u.getUsername());

            rs = ps.executeQuery();
            if (rs.next()) {
                String bId = rs.getString("USERNAME");
                //if (bId != u.getUsername())
                    //throw new DaoException("UserName " + u.getUsername() + " already exists for another customer");
            }

            String command = "UPDATE customer SET PHONE =? WHERE USERNAME=?";
            ps = con.prepareStatement(command);
            logger.info("Phone number updated");
            ps.setString(1, u.getPhone());
            ps.setString(2, u.getUsername());                        
           
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Change Phone Number SQL Exception (DAO)");
            throw new DaoException("amendUser: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Change Phone Number SQL Exception (DAO)");
                throw new DaoException("amendUser(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Add a user to the database, used for registration
    public int addUser(User u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            
            String query = "SELECT USERNAME FROM customer WHERE  USERNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, u.getUsername());

            rs = ps.executeQuery();
            if (rs.next()) {
                logger.warn("User already existed");
                throw new DaoException("USERNAME " + u.getUsername() + " already exists");
            } 

            String command = "INSERT INTO customer (USERNAME, PASSWORD, LASTNAME, FIRSTNAME, AddressLine1, AddressLine2, CITY, POSTALCODE, PHONE, user_Type, googleAuth) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0)";
            ps = con.prepareStatement(command);
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getLastname());
            ps.setString(4, u.getFirstname());
            ps.setString(5, u.getAddressLine1());
            ps.setString(6, u.getAddressLine2());
            ps.setString(7, u.getCity());
            ps.setString(8, u.getPostalCode());
            ps.setString(9, u.getPhone());
            logger.info("User added Sucesfully");
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Add User SQL Exception (DAO)");
            throw new DaoException("addUser: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Add User SQL Exception (DAO)");
                throw new DaoException("addUser(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Delete a user from the database
    public int deleteUser(String Username) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();

            String command = "DELETE FROM customer WHERE USERNAME=?";
            ps = con.prepareStatement(command);
            ps.setString(1, Username);
            logger.info("User deleted (DAO)");
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Delete User SQL Exception (DAO)");
            throw new DaoException("deleteUser: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Delete User SQL Exception (DAO)");
                throw new DaoException("deleteUser(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Change the users password
    public int changePassword(User u, String OldPassword, String NewPassword) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            String query = "SELECT CUSTOMERID, USERNAME, PASSWORD FROM customer WHERE USERNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, u.getUsername());

            rs = ps.executeQuery();
            if (rs.next()) {
                String bId = rs.getString("USERNAME");
                if (OldPassword.equals(u.getPassword())){
                    logger.warn("Wrong Password entered");
                    throw new DaoException("Old Password " + OldPassword + " not the correct password");
                }}

            String command = "UPDATE customer SET PASSWORD =? WHERE USERNAME=? And PASSWORD=?";
            ps = con.prepareStatement(command);
            ps.setString(1, NewPassword);
            ps.setString(2, u.getUsername());  
            ps.setString(3, OldPassword); 
           
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Change password SQL Exception (DAO)");
            throw new DaoException("changePassword: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Change password SQL Exception (DAO)");
                throw new DaoException("changePassword(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Sets a user as admin
     public int setAdmin(User c) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            // Assume symbol is unique in database
            // Ensure the new symbol does not belong to another company
            String query = "SELECT USERNAME, user_Type FROM customer WHERE USERNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, c.getUsername());

            rs = ps.executeQuery();
            if (rs.next()) {
                String uId = rs.getString("USERNAME");
                //if (uId != c.getUsername())
                   // throw new DaoException("User Name " + c.getUsername() + " already exists for another user");
            }

            String command = "UPDATE customer SET user_Type=? WHERE USERNAME = ?";
            ps = con.prepareStatement(command);
            ps.setInt(1, c.getAdmin());
            ps.setString(2, c.getUsername());
           
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Set Admin SQL Exception (DAO)");
            throw new DaoException("setAdmin: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Set Admin SQL Exception (DAO)");
                throw new DaoException("setAdmin(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
     
     //If the user opts into google auth this function will be used
     public int setAuth(User c) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            // Assume symbol is unique in database
            // Ensure the new symbol does not belong to another company
            String query = "SELECT USERNAME, googleAuth FROM customer WHERE USERNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, c.getUsername());

            rs = ps.executeQuery();
            if (rs.next()) {
                String uId = rs.getString("USERNAME");
                //if (uId != c.getUsername())
                   // throw new DaoException("User Name " + c.getUsername() + " already exists for another user");
            }

            String command = "UPDATE customer SET googleAuth=? WHERE USERNAME = ?";
            ps = con.prepareStatement(command);
            ps.setInt(1, c.getGoogleAuth());
            ps.setString(2, c.getUsername());
           
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Set googleAuth SQL Exception (DAO)");
            throw new DaoException("setAdmin: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("googleAuth SQL Exception (DAO)");
                throw new DaoException("setAdmin(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    
}
