/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import JavaClasses.Product_Order;
import Exceptions.DaoException;

import javax.sql.DataSource;
import org.apache.log4j.Logger;
/**
 *
 * @author Michael
 */
public class Product_OrderDAO extends Dao {
    static Logger logger = Logger.getLogger(Product_OrderDAO.class.getName());
    
    public Product_OrderDAO(DataSource ds)
{
	super(ds); //super() calls the parent constructor
}
    //Functionlity to list all producsts within the product table
    public List<Product_Order> findAllProducts() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Product_Order> orders = new ArrayList<Product_Order>();
        try {
            con = this.getConnection();
            //SQL query to return all values in database
            String query = "SELECT * FROM product_order";
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            //Gathers each value and puts in to object
            while (rs.next()) {
                int prodId =rs.getInt("ProductOrderID");
                int SalesID = rs.getInt("SalesID");
                int ItemID = rs.getInt("ItemID");
                int amount = rs.getInt("Amount");
                
                Product_Order s = new Product_Order(prodId,SalesID,ItemID, amount);
                
                orders.add(s);
            }
        } catch (SQLException e) {
            logger.warn("findAllOrders SQL Exception (DAO)");
            throw new DaoException("findAllOrders() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("findAllOrders SQL Exception (DAO)");
                throw new DaoException(e.getMessage());
            }
        }
        return orders;     // may be empty
    }
    
    //Gathers products by product ID
    public  List<Product_Order> findProductssBySalesOrderID(int ID) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Product_Order u = null;
        List<Product_Order> products = new ArrayList<Product_Order>();
        
        try {
            con = this.getConnection();
            //Run SQL query to gather orders
            String query = "SELECT * FROM Product_Order WHERE SalesID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, ID);
            
            
            rs = ps.executeQuery();
            //Gets values and put in array
            if (rs.next()) {
                int prodId =rs.getInt("ProductOrderID");
                int SalesID = rs.getInt("SalesID");
                int ItemID = rs.getInt("ItemID");
                int amount = rs.getInt("Amount");
                
                u = new Product_Order(prodId,SalesID,ItemID,amount);
                products.add(u);
                
            }
        } catch (SQLException e) {
            logger.warn("findAllOrdersBySalesID SQL Exception (DAO)");
            throw new DaoException("findItemsBySalesOrderID " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("findAllOrdersBySalesID SQL Exception (DAO)");
                throw new DaoException("findItemsBySalesOrderID" + e.getMessage());
            }
        }
       
        return products;
        // products may be null 
    }
    
    //Function to add new product order to database
    public int addProduct(Product_Order u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            //Check if product order is already added
            String query = "SELECT ProductOrderID FROM Product_Order WHERE  ProductOrderID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, u.getProductId());

            rs = ps.executeQuery();
            //Throw error if already added
            if (rs.next()) {
                throw new DaoException("Product_Order " + u.getProductId() + " already exists");
            } 
            //Insert product order to database as order is not already added
            String command = "INSERT INTO Product_Order (ProductOrderID, SalesID, ItemID, Amount ) VALUES(?, ?, ?, ?)";
            ps = con.prepareStatement(command);
            ps.setInt(1, u.getProductId());
            ps.setInt(2, u.getSalesId());
            ps.setInt(3, u.getItemId());
            ps.setInt(4, u.getAmount());
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Add Product SQL Exception (DAO)");
            throw new DaoException("addProduct " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Add Product SQL Exception (DAO)");
                throw new DaoException("addProduct(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Function to delete product from database by product ID
     public int deleteProductByProductOrderID(int ProductOrderID) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            //Delete product from database by product ID
            String command = "DELETE FROM Product_Order WHERE ProductOrderID=?" ;
            ps = con.prepareStatement(command);
            ps.setInt(1,ProductOrderID);

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Delete Product By ID SQL Exception (DAO)");
            throw new DaoException("deleteProductOrder: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Delete Product By ID SQL Exception (DAO)");
                throw new DaoException("deleteProductOrder(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
     
     //Function to delete product from database by Sales ID
     public int deleteProductBySalesID(int SalesID) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            
            //SQL query to dlete item by Sales ID
            String command = "DELETE FROM product_order WHERE SalesID =?" ;
            ps = con.prepareStatement(command);
            ps.setInt(1,SalesID);
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Delete Product By ID SQL Exception (DAO)");
            throw new DaoException("deleteProductBySalesID: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Delete Product By Sales ID SQL Exception (DAO)");
                throw new DaoException("deleteProductBySalesID(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
     
     //Funtion to edit order
     public int amendProductOrder(Product_Order a) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            //Find order to edit
            String query = "SELECT ProductOrderID FROM product_order WHERE ProductOrderID  = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, a.getProductId());

            rs = ps.executeQuery();
            if (rs.next()) {
                int bId = rs.getInt("ItemID");
                if (bId != a.getProductId())
                    throw new DaoException("ItemName " + a.getProductId() + " already exists for another item");
            }
            //Update order it it has been found
            String command = "UPDATE product_order SET ProductOrderID =?, SalesID =?, ItemID=?, Amount =? WHERE ProductOrderID=?";
            ps = con.prepareStatement(command);
            ps.setInt(1, a.getProductId());
            ps.setInt(2,a.getSalesId());
            ps.setInt(3, a.getItemId());
            ps.setInt(4, a.getAmount());
            ps.setInt(5, a.getProductId());
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Amend Product SQL Exception (DAO)");
            throw new DaoException("amendProductOrder: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Amend Product SQL Exception (DAO)");
                throw new DaoException("amendProductOrder(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
}
