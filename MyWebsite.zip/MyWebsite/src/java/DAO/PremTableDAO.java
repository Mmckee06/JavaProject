/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import JavaClasses.PremTable;
import Exceptions.DaoException;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
/**
 * Provides all the functionality needed for the premiership table. This includes thing like getting data
 * from this database, updating the database or deleting.
 * @author mmckee
 */
public class PremTableDAO extends Dao {
    
    //Declared for displaying error messages
     static Logger logger = Logger.getLogger(PremTableDAO.class.getName());
    
    public PremTableDAO(DataSource ds)
{
	super(ds); //super() calls the parent constructor
}
    
    //This function will get all data from the database and put it within an array
    public List<PremTable> findAllTeams() throws DaoException {
        //Decalre variables
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<PremTable> teams = new ArrayList<PremTable>();
        try {
            //Get connection
            con = this.getConnection();
            //SQL query to run
            String query = "SELECT * FROM premiership ORDER BY POINTS DESC";
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            //Retrieve each different field in the table and put into a variable
            while (rs.next()) {
                int TeamID = rs.getInt("TEAMID");
                int TeamPos = rs.getInt("POSITION");
                String teamName = rs.getString("TEAMNAME");
                int GamesPlayed = rs.getInt("GAMESPLAYED");
                int goalsFor = rs.getInt("GOALSFOR");
               int goalsAgainst = rs.getInt("GOALSAGAINST");
                int goalsDif = rs.getInt("GOALDIFFERENCE");
                 int points = rs.getInt("POINTS");
                
                 //Gets the infor gathers and puts into a PpremTable object
                PremTable t = new PremTable(TeamID,TeamPos,teamName,GamesPlayed,goalsFor,goalsAgainst,goalsDif,points);
                teams.add(t); // Add item to array and keeps adding teams until loop finishes
            }
        } catch (SQLException e) {
            logger.warn("List PremTable SQL Exception (DAO)");
            throw new DaoException("findAllTeams() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("List PremTable SQL Exception (DAO)");
                throw new DaoException(e.getMessage());
            }
        }
        return teams;     // may be empty
    }
    
    //Function to find a certain team in database by team name
     public PremTable findTeamByTeamName(String team) throws DaoException {
        //Decalre variables
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        PremTable t = null;
        try {
            con = this.getConnection();
            //Run quesy to find team
            String query = "SELECT * FROM premiership WHERE TEAMNAME = ?" ;
            ps = con.prepareStatement(query);
            //Adds teamname to SQL query, prepared statement 
            ps.setString(1, team);
            
            
            rs = ps.executeQuery();
            
            //Gathers data and puts into an object
            if (rs.next()) {
                int TeamID = rs.getInt("TEAMID");
                int TeamPos = rs.getInt("POSITION");
                String teamName = rs.getString("TEAMNAME");
                int GamesPlayed = rs.getInt("GAMESPLAYED");
                int goalsFor = rs.getInt("GOALSFOR");
               int goalsAgainst = rs.getInt("GOALSAGAINST");
                int goalsDif = rs.getInt("GOALDIFFERENCE");
                 int points = rs.getInt("POINTS");
                
                 t = new PremTable(TeamID,TeamPos,teamName,GamesPlayed,goalsFor,goalsAgainst,goalsDif,points);
                
                
            }
        } catch (SQLException e) {
            logger.warn("findTeamByName SQL Exception (DAO)");
            throw new DaoException("findTeamByName " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("findTeamByName SQL Exception (DAO)");
                throw new DaoException("findTeamByName" + e.getMessage());
            }
        }
       
        return t;
        // t may be null 
    }
     
     //Function to find team with reater points than value given
     public List<PremTable> findTeamsByPointsGreaterThan(int point) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        PremTable t = null;
        List<PremTable> teams = new ArrayList<PremTable>();
        
        try {
            con = this.getConnection();
            //Run query
            String query = "SELECT * FROM premiership WHERE POINTS >= ?";
            ps = con.prepareStatement(query);
            //Provide points value to SQL query
            ps.setInt(1, point);
            
            
            rs = ps.executeQuery();
            //Finds each team that has points greater than value provided and puts in database
           while (rs.next()) {
                int TeamID = rs.getInt("TEAMID");
                int TeamPos = rs.getInt("POSITION");
                String teamName = rs.getString("TEAMNAME");
                int GamesPlayed = rs.getInt("GAMESPLAYED");
                int goalsFor = rs.getInt("GOALSFOR");
               int goalsAgainst = rs.getInt("GOALSAGAINST");
                int goalsDif = rs.getInt("GOALDIFFERENCE");
                 int points = rs.getInt("POINTS");
                
                 t = new PremTable(TeamID,TeamPos,teamName,GamesPlayed,goalsFor,goalsAgainst,goalsDif,points);
                 teams.add(t);
                
            }
        } catch (SQLException e) {
            logger.warn("findTeamsByPointsGreaterThan SQL Exception (DAO)");
            throw new DaoException("findTeamsByPointsGreaterThan " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("findTeamsByPointsGreaterThan SQL Exception (DAO)");
                throw new DaoException("findTeamsByPointsGreaterThan" + e.getMessage());
            }
        }
       
        return teams;
        // teams may be null 
    }
     
     //Finds each team that has points less than value provided and puts in database
    public List<PremTable> findTeamsByPointsLessThan(int point) throws DaoException {
        //Decalre variables
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        PremTable t = null;
        List<PremTable> teams = new ArrayList<PremTable>();
        
        try {
            con = this.getConnection();
            //Run SQL query
            String query = "SELECT * FROM premiership WHERE POINTS <= ?";
            ps = con.prepareStatement(query);
            //Add value provided to SQL query
            ps.setInt(1, point);
            
            
            rs = ps.executeQuery();
            //Finds each team with points less than given value and adds to array
           while (rs.next()) {
                int TeamID = rs.getInt("TEAMID");
                int TeamPos = rs.getInt("POSITION");
                String teamName = rs.getString("TEAMNAME");
                int GamesPlayed = rs.getInt("GAMESPLAYED");
                int goalsFor = rs.getInt("GOALSFOR");
               int goalsAgainst = rs.getInt("GOALSAGAINST");
                int goalsDif = rs.getInt("GOALDIFFERENCE");
                 int points = rs.getInt("POINTS");
                
                 t = new PremTable(TeamID,TeamPos,teamName,GamesPlayed,goalsFor,goalsAgainst,goalsDif,points);
                 teams.add(t);
                
            }
        } catch (SQLException e) {
            logger.warn("findTeamsByPointsLessThan SQL Exception (DAO)");
            throw new DaoException("findTeamsByPointsLessThan " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("findTeamsByPointsLessThan SQL Exception (DAO)");
                throw new DaoException("findTeamsByPointsLessThan" + e.getMessage());
            }
        }
       
        return teams;
        // teams may be null 
    }
    
    //This functionality adds a new team to the database
   public int addTeam(PremTable u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            //Run QL query to see if team is already added
            String query = "SELECT TEAMNAME FROM premiership WHERE  TEAMNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, u.getTeamName());

            rs = ps.executeQuery();
            //If team already added throw error
            if (rs.next()) {
                throw new DaoException("TeamName " + u.getTeamName() + " already exists");
            } 
            
            //Team not already added so can be inserted into database
            String command = "INSERT INTO premiership (TeamID,POSITION,teamName,GamesPlayed,goalsFor,goalsAgainst,GOALDIFFERENCE,points) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
                ps = con.prepareStatement(command);
            ps.setInt(1, u.getTeamId());
            ps.setInt(2, u.getTeamPos());
            ps.setString(3, u.getTeamName());
            ps.setInt(4, u.getGamesPlayed());
            ps.setInt(5, u.getGoalsFor());
            ps.setInt(6, u.getGoalsAgainst());
            ps.setInt(7, u.getGoalDifference());
            ps.setInt(8, u.getPoints());
            
   
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Add team SQL Exception (DAO)");
            throw new DaoException("addTeam: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Add team SQL Exception (DAO)");
                throw new DaoException("addTeam(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
   
   //Function to delete team from database
   public int deleteTeam(String Teamname) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            //SQL query to delete team by team name
            String command = "DELETE FROM premiership WHERE TEAMNAME=?";
            ps = con.prepareStatement(command);
            ps.setString(1, Teamname);

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Delete team SQL Exception (DAO)");
            throw new DaoException("deleteTeam: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Delete team SQL Exception (DAO)");
                throw new DaoException("deleteTeam(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
   
   //Update point of a team
  public int updatePoints(PremTable u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            //Run SQL query to find team
            String query = "SELECT TEAMNAME FROM premiership WHERE  TEAMNAME = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, u.getTeamName());

            rs = ps.executeQuery();
             
            //After team is found update it with information provided
            String command = "UPDATE premiership SET POSITION=?, GamesPlayed =?, GOALSFOR =?, GOALSAGAINST =?, GOALDIFFERENCE =?, POINTS =? WHERE TEAMNAME =?";
            ps = con.prepareStatement(command);
            ps.setInt(1,u.getTeamPos());
            ps.setInt(2,u.getGamesPlayed());
            ps.setInt(3, u.getGoalsFor());
            ps.setInt(4, u.getGoalsAgainst());
            ps.setInt(5, u.getGoalDifference());
            ps.setInt(6, u.getPoints());
            ps.setString(7, u.getTeamName());                        
           
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Update team SQL Exception (DAO)");
            throw new DaoException("updatePoints: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Update team SQL Exception (DAO)");
                throw new DaoException("updatePoints(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
  
 
  
  
  
   
    
}
    
    

    
   
