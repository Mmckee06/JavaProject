/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import JavaClasses.Store;
import Exceptions.DaoException;
import java.sql.CallableStatement;
import java.util.Properties;

import javax.sql.DataSource;
import org.apache.log4j.Logger;

/**
 *
 * @author mmckee
 */
public class StoreDAO extends Dao {
    
    static Logger logger = Logger.getLogger(StoreDAO.class.getName());
    Properties props = new Properties();
    
    public StoreDAO(DataSource ds)
{
	super(ds);  //super() calls the parent constructor
}
    
    //List all items in database, put in array to display
    public List<Store> findAllItems() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Store> items = new ArrayList<Store>();
        try {
            con = this.getConnection();

            String query = "SELECT * FROM store";
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            while (rs.next()) {
                int ItemID = rs.getInt("ItemId");
                String ItemName = rs.getString("ItemName");
                String ItemType = rs.getString("ItemType");
                int quantity =rs.getInt("Quantity");
                double price = rs.getDouble("Price");
                String itemImage = rs.getString("ItemImage");
                Store s = new Store(ItemID,ItemName,ItemType,quantity,price,itemImage);
                
                items.add(s);
            }
        } catch (SQLException e) {
            logger.warn("List all Items SQL Exception (DAO)");
            throw new DaoException("findAllItems() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("List all Items SQL Exception (DAO)");
                throw new DaoException(e.getMessage());
            }
        }
        return items;     // may be empty
    }
    
    //Function to fin all items by a type etc football shirt
     public  List<Store> findItemsByType(String type) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Store u = null;
        List<Store> items = new ArrayList<Store>();
        
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM store WHERE ItemType = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, type);
            
            
            rs = ps.executeQuery();
            if (rs.next()) {
                int ItemID = rs.getInt("ItemId");
                String ItemName = rs.getString("ItemName");
                String ItemType = rs.getString("ItemType");
                int quantity =rs.getInt("Quantity");
                double price = rs.getDouble("Price");
                String itemImage = rs.getString("ItemImage");
                
                u = new Store(ItemID,ItemName,ItemType,quantity,price,itemImage);
                items.add(u);
                
            }
        } catch (SQLException e) {
            logger.warn("Find Items by Type SQL Exception (DAO)");
            throw new DaoException("findItemsByType " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find Items by Type SQL Exception (DAO)");
                throw new DaoException("findItemsByType" + e.getMessage());
            }
        }
       
        return items;
        // p may be null 
    }
     
     //Finds items by name
     public  Store findItemsByName(String Name) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Store u = null;
        
        
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM store WHERE ItemName = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, Name);
            
            
            rs = ps.executeQuery();
            if (rs.next()) {
                int ItemID = rs.getInt("ItemId");
                String ItemName = rs.getString("ItemName");
                String ItemType = rs.getString("ItemType");
                int quantity =rs.getInt("Quantity");
                double price = rs.getDouble("Price");
                String itemImage = rs.getString("ItemImage");
                
                u = new Store(ItemID,ItemName,ItemType,quantity,price,itemImage);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find Items by Name SQL Exception (DAO)");
            throw new DaoException("findItemsByName " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find Items by Name SQL Exception (DAO)");
                throw new DaoException("findItemsByName" + e.getMessage());
            }
        }
       
        return u;
    }
   
     //Find an item by its store ID
     public  Store findItemsByID(int ID) throws DaoException {
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Store u = null;
        
        
        try {
            con = this.getConnection();
            
            String query = "SELECT * FROM store WHERE ItemID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, ID);
            
            
            rs = ps.executeQuery();
            if (rs.next()) {
                int ItemID = rs.getInt("ItemId");
                String ItemName = rs.getString("ItemName");
                String ItemType = rs.getString("ItemType");
                int quantity =rs.getInt("Quantity");
                double price = rs.getDouble("Price");
                String itemImage = rs.getString("ItemImage");
                
                u = new Store(ItemID,ItemName,ItemType,quantity,price,itemImage);
                
                
            }
        } catch (SQLException e) {
            logger.warn("Find Items by ID SQL Exception (DAO)");
            throw new DaoException("findItemsByName " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Find Items by ID SQL Exception (DAO)");
                throw new DaoException("findItemsByName" + e.getMessage());
            }
        }
       
        return u;
    }
    
     //Add a new item to the store
    public int addItem(Store u) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            
            String query = "SELECT ItemName FROM store WHERE  ItemName = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, u.getItemName());

            rs = ps.executeQuery();
            if (rs.next()) {
                throw new DaoException("ITEMNAME " + u.getItemName() + " already exists");
            } 

            String command = "INSERT INTO store (ItemID, ItemName, ItemType, Quantity, Price, ItemImage ) VALUES(?, ?, ?, ?, ?, ?)";
            ps = con.prepareStatement(command);
            ps.setInt(1, u.getItemID());
            ps.setString(2, u.getItemName());
            ps.setString(3, u.getItemType());
            ps.setInt(4, u.getQuantity());
            ps.setDouble(5, u.getPrice());
            ps.setString(6,u.getItemImage());
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Add Item SQL Exception (DAO)");
            throw new DaoException("addItem: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Add Item SQL Exception (DAO)");
                throw new DaoException("addItem(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Delete an item from the store
    public int deleteItem(int ID) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();

            String command = "DELETE FROM store WHERE ItemID=?" ;
            ps = con.prepareStatement(command);
            ps.setInt(1,ID);

            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Delete Item SQL Exception (DAO)");
            throw new DaoException("deleteItem: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Delete Item SQL Exception (DAO)");
                throw new DaoException("deleteItem(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Edit an exiting item in the database
    public int amendItem(Store a) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            String query = "SELECT ItemID, ItemName FROM store WHERE ItemID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, a.getItemID());

            rs = ps.executeQuery();
            if (rs.next()) {
                int bId = rs.getInt("ItemID");
                //if (bId != a.getItemID())
                  //throw new DaoException("ItemName " + a.getItemName() + " already exists for another item");
            }

            String command = "UPDATE store SET ItemName =?, ItemType =?, Quantity=?, Price=?, ItemImage=? WHERE ItemID=?";
            ps = con.prepareStatement(command);
            ps.setString(1, a.getItemName());
            ps.setString(2,a.getItemType());
            ps.setInt(3, a.getQuantity());
            ps.setDouble(4, a.getPrice());
            ps.setString(5,a.getItemImage());
            ps.setInt(6, a.getItemID());
            
            rowsAffected = ps.executeUpdate();

        } catch (SQLException e) {
            logger.warn("Amend Item SQL Exception (DAO)");
            throw new DaoException("amendItem: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Amend Item SQL Exception (DAO)");
                throw new DaoException("amendItem(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
    
    //Function to discount the price of all items
     public int addDiscount(double percentage) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rowsAffected = 0;
        try {
            con = getConnection();
            String s1 = "{CALL calculatediscount(?)}";
            CallableStatement cs = con.prepareCall(s1);
            
            
            // Set variables the usual way
            cs.setDouble(1, percentage);
          
            // Execute it
            cs.execute();

        } catch (SQLException e) {
            logger.warn("Give Discount SQL Exception (DAO)");
            throw new DaoException("amendItem: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                logger.warn("Give Discount SQL Exception (DAO)");
                throw new DaoException("amendItem(): " + e.getMessage());
            }
        }
        return rowsAffected;
    }
}
