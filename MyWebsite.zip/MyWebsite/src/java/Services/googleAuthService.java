/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import DAO.MyDatasource;
import DAO.googleAuthDAO;
import Exceptions.DaoException;
import JavaClasses.googleAuth;
import com.warrenstrange.googleauth.GoogleAuthenticator;
import java.util.List;

/**
 *
 * @author Michael
 */
public class googleAuthService {
    
    public googleAuth FindUser(String username)
    {
        
       googleAuth u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //UserDAO dao = new UserDAO();
            googleAuthDAO dao = new googleAuthDAO( new MyDatasource() );
            u = dao.findAuthByUsername(username);
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
    public boolean checkCode(String Username, int code) {
        GoogleAuthenticator ga = new GoogleAuthenticator();
        ga.setWindowSize(5);  //should give 5 * 30 seconds of grace...

         boolean isCodeValid = ga.authorizeUser(Username, code);
        return isCodeValid;
        //System.out.println("Check VALIDATION_CODE = " + isCodeValid);
      
    }
    
    public List<googleAuth> getAllAuths()
    {
        List<googleAuth> auths = null;
        try 
        {
            //StoreDAO dao = new StoreDAO();
            googleAuthDAO dao = new googleAuthDAO( new MyDatasource() );
            auths = dao.findAllAuths();
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return auths;	
    }
    
    public googleAuth DeleteByAuthID( int ID)
    {
        
        googleAuth u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //Sales_OrderDAO dao = new Sales_OrderDAO();
            googleAuthDAO dao = new googleAuthDAO( new MyDatasource() );
            dao.deleteAuthByID(ID);
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
}
