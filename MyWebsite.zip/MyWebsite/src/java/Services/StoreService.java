/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import DAO.MyDatasource;
import Exceptions.DaoException;
import java.util.List;
import JavaClasses.Store;
import DAO.StoreDAO;
/**
 * This uses the store DAO, calls the functions within the DAO and returns information needed.
 * @author Michael
 */
public class StoreService {
    
    public List<Store> getAllItems()
    {
        List<Store> items = null;
        try 
        {
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );
            items = dao.findAllItems();
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return items;	
    }	
    
    public Store DeleteItem(int id)
    {
        
        Store i = null; 
        
        try 
        {
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );
            dao.deleteItem(id);
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return i;
    }
    
    public Store findItemByID(int id)
    {
        Store u = null;
        try 
        {
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );
            u = dao.findItemsByID(id);
            
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
    
    
    public Store Edit(int ID, String itemname, String itemType, int Quantity, double Price, String image)
    {
        
        Store u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );
            
            u = dao.findItemsByID(ID);
            u.setItemName(itemname);
            u.setItemType(itemType);
            u.setQuantity(Quantity);
            u.setPrice(Price);
            u.setItemImage(image);
            
            dao.amendItem(u);

        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
    public Store addItem(  String itemname, String itemType,int quantity, double price, String image)
    {
        Store u = new Store( itemname, itemType, quantity, price,image);
        try 
        {
            
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );
            dao.addItem(u);   
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
    public Store findItemforArrayList(int id, int sub)
    {
        Store u = new Store();
        try 
        {
            
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );
             u = dao.findItemsByID(id);
             
             if (u.getQuantity() >= sub){
               u.subtractQuantity(sub); 
                dao.amendItem(u);
             } else {
                 return null;
             }
             
            
        } 
        
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
    public Store giveDdiscount(double per)
    {
        Store u = null;
        try 
        {
            
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );
             dao.addDiscount(per);
        } 
        
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
  
}
    


    

