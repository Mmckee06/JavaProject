/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import DAO.MyDatasource;
import Exceptions.DaoException;
import java.util.List;
import JavaClasses.PremTable;
import DAO.PremTableDAO;
/**
 *
 * @author Michael
 */
public class TableService {
    
    public List<PremTable> getAllTeams()
    {
        List<PremTable> items = null;
        try 
        {
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );
            items = dao.findAllTeams();
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return items;	
    }	
    
    public PremTable Edit(String itemname, int GamesPlayed,int forGoal, int against, int dif, int points)
    {
        
        PremTable u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );
            
            u = dao.findTeamByTeamName(itemname);
            u.setGamesPlayed(GamesPlayed);
            u.setGoalsFor(forGoal);
            u.setGoalsAgainst(against);
            u.setGoalDifference(dif);
            u.setPoints(points);
            dao.updatePoints(u);
            

        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
     public PremTable addItem(int pos, String itemname, int GamesPlayed,int forGoal, int against, int dif, int points)
    {
        PremTable u = new PremTable(pos,itemname,GamesPlayed,forGoal,against,dif,points);
        try 
        {
            
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );
            dao.addTeam(u);
            
            
            
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }

     public PremTable DeleteTeam(String teamname)
    {
        
        PremTable u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );
            dao.deleteTeam(teamname);
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
}
