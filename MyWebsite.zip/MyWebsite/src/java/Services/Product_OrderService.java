/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import DAO.MyDatasource;
import Exceptions.DaoException;
import java.util.List;
import JavaClasses.Product_Order;
import DAO.Product_OrderDAO;
/**
 *
 * @author Michael
 */
public class Product_OrderService {
    
    public List<Product_Order> getAllProducts()
    {
        List<Product_Order> products = null;
        try 
        {
            //Product_OrderDAO dao = new Product_OrderDAO();
            Product_OrderDAO dao = new Product_OrderDAO( new MyDatasource() );
            products = dao.findAllProducts();
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return products;	
    }
    
    public List<Product_Order> findProductsBySalesOrderID(int ID)
    {
        List<Product_Order> products = null;
        try 
        {
            //Product_OrderDAO dao = new Product_OrderDAO();
            Product_OrderDAO dao = new Product_OrderDAO( new MyDatasource() );
            products = dao.findProductssBySalesOrderID(ID);
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return products;	
    }
    
     public Product_Order addProduct(int salesID, int itemID, int amount)
    {
        Product_Order u = new Product_Order(salesID, itemID, amount);
        try 
        {
            
            //Product_OrderDAO dao = new Product_OrderDAO();
            Product_OrderDAO dao = new Product_OrderDAO( new MyDatasource() );
            dao.addProduct(u);
            
            
            
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
     
      public Product_Order DeleteProductBySalesID( int salesID)
    {
        
        Product_Order u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //Product_OrderDAO dao = new Product_OrderDAO();
            Product_OrderDAO dao = new Product_OrderDAO( new MyDatasource() );
            dao.deleteProductBySalesID(salesID);
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
    
}
