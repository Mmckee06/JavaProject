/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import DAO.MyDatasource;
import Exceptions.DaoException;
import java.util.List;
import JavaClasses.User;
import DAO.UserDAO;
import com.warrenstrange.googleauth.GoogleAuthenticator;

/**
 *
 * @author Michael
 */
public class UserService {
    
    public User login(String username, String password)
    {
        User u = null;
        try 
        {
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            u = dao.findUsersByUsernamePassword(username, password);
            
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
    public User Register( String username, String password, String LastName, String FirstName, String AddressLine1, String AddressLine2, String City, String POSTALCODE, String Phone, int user_Type, int googleAuth)
    {
        User u = new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type,googleAuth);
        try 
        {
            
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            dao.addUser(u);
            
            
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
	
    public List<User> getAllUsers()
    {
        List<User> users = null;
        try 
        {
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            users = dao.findAllUsers();
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return users;	
    }	
    
    public User Edit( String username, String LastName, String FirstName, String AddressLine1, String AddressLine2, String City, String POSTALCODE, String Phone, int user_Type)
    {
        
        User u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            
            u = dao.findUsersByUsername(username);
            u.setUsername(username);
            u.setFirstname(FirstName);
            u.setLastname(LastName);
            u.setAddressLine1(AddressLine1);
            u.setAddressLine2(AddressLine2);
            u.setCity(City);
            u.setPostalCode(POSTALCODE);
            u.setPhone(Phone);
            
            dao.amendUserNameAddress(u);

        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
    
     public User ChangePassword( String username, String OldPassword, String NewPassword)
    {
        
        User u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            
            u = dao.findUsersByUsername(username);
            u.setUsername(username);
            u.setPassword(NewPassword);
            
            dao.changePassword(u, OldPassword, NewPassword);
            

        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
     
      public User ChangeAdmin(String username)
    {
        
        User u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            
            u = dao.findUsersByUsername(username);
            u.setAdmin();
            dao.setAdmin(u);

        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
      
      public User DeleteUser( String username)
    {
        
        User u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            dao.deleteUser(username);
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
      
       public User FindUser(String username)
    {
        
        User u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            u = dao.findUsersByUsername(username);
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
       
       public User ChangeGoogleAuth(String username, int num)
    {
        
        User u = null; //new User(username,password,LastName,FirstName,AddressLine1,AddressLine2,City,POSTALCODE,Phone,user_Type);
        
        try 
        {
            
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            
            u = dao.findUsersByUsername(username);
            u.setGoogleAuth(num);
            dao.setAuth(u);

        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return u;
    }
       
       
}



    

