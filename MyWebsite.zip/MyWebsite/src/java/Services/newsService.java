/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import DAO.MyDatasource;
import DAO.newsDAO;
import Exceptions.DaoException;
import JavaClasses.News;
import java.util.List;

/**
 *
 * @author Michael
 */
public class newsService {
    
    public List<News> getAllNews()
    {
        List<News> items = null;
        try 
        {
            //StoreDAO dao = new StoreDAO();
            newsDAO dao = new newsDAO( new MyDatasource() );
            items = dao.findAllNews();
        } 
        catch (DaoException e) 
        {
            e.printStackTrace();
        }
        return items;	
    }
    
}
