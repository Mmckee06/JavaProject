/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaClasses;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * This Store class simple holds the data for the store database and provides basie functionality for the
 * object like add, delete, edit and display.
 * @author mmckee
 */
public class Store implements Serializable  {
    
    private int ItemID;
    private String ItemName;
    private String ItemType;
    private int quantity;
    private double Price;
    private int quatityBasket;
    private String itemImage;
    
    public Store() {
        ItemID = 10;
        ItemName = "Nike Football";
        ItemType = "football";
        quantity = 10;
        Price = 5.99;
        quatityBasket = 1;
        itemImage = "images/no-Image.png";
    }
    


    public Store(int ItemID, String ItemName, String ItemType, int quantity, Double Price,String itemImage) {
        this.ItemID = ItemID;
        this.ItemName = ItemName;
        this.ItemType = ItemType;
        this.quantity = quantity;
        this.Price = Price;
        quatityBasket = 1;
        this.itemImage = itemImage;
    }
    
    public Store( String ItemName, String ItemType,int quantity, Double Price, String itemImage) {
        this.ItemName = ItemName;
        this.ItemType = ItemType;
        this.quantity = quantity;
        this.Price = Price;
        quatityBasket = 1;
        this.itemImage = itemImage;
    }

    public int getItemID() {
        return ItemID;
    }

    public void setItemID(int ItemID) {
        this.ItemID = ItemID;
    }

    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String ItemName) {
        this.ItemName = ItemName;
    }

    public String getItemType() {
        return ItemType;
    }

    public void setItemType(String ItemType) {
        this.ItemType = ItemType;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public int getQuantity() {
        return quantity;
    }
    
    public int addQuantity(int num) {
        quantity = quantity + num;
        return quantity;
    }
    
    public int subtractQuantity(int num) {
        quantity = quantity - num;
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getItemImage() {
        return itemImage;
    }

    public void setItemImage(String itemImage) {
        this.itemImage = itemImage;
    }
    

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + this.ItemID;
        hash = 53 * hash + (this.ItemName != null ? this.ItemName.hashCode() : 0);
        hash = 53 * hash + (this.ItemType != null ? this.ItemType.hashCode() : 0);
        hash = 53 * hash + this.quantity;
        hash = 53 * hash + (int) (Double.doubleToLongBits(this.Price) ^ (Double.doubleToLongBits(this.Price) >>> 32));
        return hash;
    }
    

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Store other = (Store) obj;
        if (this.ItemID != other.ItemID) {
            return false;
        }
        if ((this.ItemName == null) ? (other.ItemName != null) : !this.ItemName.equals(other.ItemName)) {
            return false;
        }
        if ((this.ItemType == null) ? (other.ItemType != null) : !this.ItemType.equals(other.ItemType)) {
            return false;
        }
        if (Double.doubleToLongBits(this.Price) != Double.doubleToLongBits(other.Price)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Store{" + "ItemID=" + ItemID + ", ItemName=" + ItemName + ", ItemType=" + ItemType + ", Quantity= " + quantity + "Price=" + Price + '}';
    }
    
    public void display(){
        System.out.printf("%10d  %-10s%-10s%-10s%-10s\n",
            ItemID, ItemName, ItemType,quantity, Price,itemImage);
    }

    public int getQuatityBasket() {
        return quatityBasket;
    }

    public void setQuatityBasket(int quatityBasket) {
        this.quatityBasket = quatityBasket;
    }
    
    public int addQuantityBasket(int num){
        quatityBasket = quatityBasket + num;
        return quatityBasket;
    }
    
    public int SubQuantityBasket(int num){
        quatityBasket = quatityBasket - num;
        
        
        return quatityBasket;
    }
    
    public boolean CheckifNull(){
      if (quatityBasket <= 0){
            return true;
        }  
      return false;
    }
    
  
    
}

