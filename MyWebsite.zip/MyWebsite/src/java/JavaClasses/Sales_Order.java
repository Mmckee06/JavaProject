/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package JavaClasses;

import java.io.Serializable;

/**
 * This Sales_Order class simple holds the data for the sales_order database and provides basie functionality for the
 * object like add, delete, edit and display.
 * @author Michael
 */
public class Sales_Order implements Serializable {
    
    private int salesId;
    private int CustID;
    private int totalItems;
    private double total;

    public Sales_Order(int salesId, int CustID, int totalItems, double total) {
       this.salesId = salesId;
       this.CustID = CustID;
       this.totalItems = totalItems;
       this.total = total;
    }
    
    public Sales_Order(int CustID, int totalItems, double total) {
        this.CustID = CustID;
        this.totalItems = totalItems;
        this.total = total;
    }

    
    
    public int getSalesId() {
        return salesId;
    }

    public void setSalesId(int salesId) {
        this.salesId = salesId;
    }

    public int getCustID() {
        return CustID;
    }

    public void setCustID(int CustID) {
        this.CustID = CustID;
    }

    public int getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
    }
    

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 67 * hash + this.salesId;
        hash = 67 * hash + this.CustID;
        hash = 67 * hash + this.totalItems;
        hash = 67 * hash + (int) (Double.doubleToLongBits(this.total) ^ (Double.doubleToLongBits(this.total) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Sales_Order other = (Sales_Order) obj;
        if (this.salesId != other.salesId) {
            return false;
        }
        if (this.CustID != other.CustID) {
            return false;
        }
        if (this.totalItems != other.totalItems) {
            return false;
        }
        if (Double.doubleToLongBits(this.total) != Double.doubleToLongBits(other.total)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Sales_Order{" + "salesId=" + salesId + ", CustID=" + CustID + ", totalItems=" + totalItems + ", total=" + total + '}';
    }
    
    public void display(){
        System.out.printf("%10d  %-10s%-10s%-10s\n",
            salesId, CustID, totalItems,total);
    }

}