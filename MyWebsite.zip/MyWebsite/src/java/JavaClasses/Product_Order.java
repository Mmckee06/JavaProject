/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package JavaClasses;

import java.io.Serializable;

/**
 * This Product_order class simple holds the data for the product_order database and provides basie functionality for the
 * object like add, delete, edit and display.
 * @author Michael
 */
public class Product_Order implements Serializable {
   
    private int productId;
    private int salesId;
    private int itemId;
    private int amount;

    public Product_Order(int productId, int salesId, int itemId, int amount) {
        this.productId = productId;
        this.salesId = salesId;
        this.itemId = itemId;
        this.amount = amount;
    }

    public Product_Order(int salesId, int itemId, int amount) {
        this.salesId = salesId;
        this.itemId = itemId;
        this.amount = amount;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getSalesId() {
        return salesId;
    }

    public void setSalesId(int salesId) {
        this.salesId = salesId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int IitemId) {
        this.itemId = IitemId;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.productId;
        hash = 97 * hash + this.salesId;
        hash = 97 * hash + this.itemId;
        hash = 97 * hash + this.amount;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Product_Order other = (Product_Order) obj;
        if (this.productId != other.productId) {
            return false;
        }
        if (this.salesId != other.salesId) {
            return false;
        }
        if (this.itemId != other.itemId) {
            return false;
        }
        if (this.amount != other.amount) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Product_Order{" + "productId=" + productId + ", salesId=" + salesId + ", itemId=" + itemId + ", amount=" + amount + '}';
    }
    
    public void display(){
        System.out.printf("%10d  %-10s%-10s%-10s\n",
            productId, salesId, itemId,amount);
    }

    
    
    
}
