/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaClasses;

import java.io.Serializable;
import java.util.Objects;

/**
 * This User class simple holds the data for the customer database and provides basie functionality for the
 * object like add, delete, edit and display.
 * @author mmckee
 */
public class User implements Serializable{
    
    private int cusomerId;
    private String username;
    private String password;
    private String lastname;
    private String firstname;
    private String AddressLine1;
    private String AddressLine2;
    private String city;
    private String postalCode;
    private String phone;
    private int admin;
    private int googleAuth;
    

    public User() {
        
        username = "";
        password = "";
        lastname = "";
        firstname = "";
        AddressLine1 = "";
        AddressLine2 = "";
        city = "";
        postalCode = "";
        phone = ""; 
        admin = 0;
        googleAuth = 0;
        
    }

    public User(int custId, String username, String password, String lastname, String firstname, String AddressLine1, String AddressLine2, String city, String postalCode, String phone, int admin, int googleAuth) {
        this.cusomerId = custId;
        this.username = username;
        this.password = password;
        this.lastname = lastname;
        this.firstname = firstname;
        this.AddressLine1 = AddressLine1;
        this.AddressLine2 = AddressLine2;
        this.city = city;
        this.postalCode = postalCode;
        this.phone = phone;
        this.admin = admin;
        this.googleAuth = googleAuth;
    }

    
    public User(String username, String password, String lastname, String firstname, String AddressLine1,
            String AddressLine2, String city, String postalCode,String phone,int adMin, int googleAuth) {
        this.username = username;
        this.password = password;
        this.lastname = lastname;
        this.firstname = firstname;
        this.AddressLine1 = AddressLine1;
        this.AddressLine2 = AddressLine2;
        this.city = city;
        this.postalCode = postalCode;
        this.phone = phone;
        this.admin = adMin;
        this.googleAuth = googleAuth;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public int getCusomerId() {
        return cusomerId;
    }

    public void setCusomerId(int custId) {
        this.cusomerId = custId;
    }

    public String getAddressLine1() {
        return AddressLine1;
    }

    public void setAddressLine1(String AddressLine1) {
        this.AddressLine1 = AddressLine1;
    }

    public String getAddressLine2() {
        return AddressLine2;
    }

    public void setAddressLine2(String AddressLine2) {
        this.AddressLine2 = AddressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }
    
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getGoogleAuth() {
        return googleAuth;
    }

    public void setGoogleAuth(int googleAuth) {
        this.googleAuth = googleAuth;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + this.cusomerId;
        hash = 83 * hash + Objects.hashCode(this.username);
        hash = 83 * hash + Objects.hashCode(this.password);
        hash = 83 * hash + Objects.hashCode(this.lastname);
        hash = 83 * hash + Objects.hashCode(this.firstname);
        hash = 83 * hash + Objects.hashCode(this.AddressLine1);
        hash = 83 * hash + Objects.hashCode(this.AddressLine2);
        hash = 83 * hash + Objects.hashCode(this.city);
        hash = 83 * hash + Objects.hashCode(this.postalCode);
        hash = 83 * hash + Objects.hashCode(this.phone);
        hash = 83 * hash + this.admin;
        hash = 83 * hash + this.googleAuth;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (this.cusomerId != other.cusomerId) {
            return false;
        }
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        if (!Objects.equals(this.lastname, other.lastname)) {
            return false;
        }
        if (!Objects.equals(this.firstname, other.firstname)) {
            return false;
        }
        if (!Objects.equals(this.AddressLine1, other.AddressLine1)) {
            return false;
        }
        if (!Objects.equals(this.AddressLine2, other.AddressLine2)) {
            return false;
        }
        if (!Objects.equals(this.city, other.city)) {
            return false;
        }
        if (!Objects.equals(this.postalCode, other.postalCode)) {
            return false;
        }
        if (!Objects.equals(this.phone, other.phone)) {
            return false;
        }
        if (this.admin != other.admin) {
            return false;
        }
        if (this.googleAuth != other.googleAuth) {
            return false;
        }
        return true;
    }
    
    
 public void display(){
        System.out.printf(" %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n",
            username, password, lastname, firstname, AddressLine1, AddressLine2, city, postalCode, phone, admin, googleAuth);
    }

    @Override
    public String toString() {
        return "User{" + "cusomerId=" + cusomerId + ", username=" + username + ", password=" + password + ", lastname=" + lastname + ", firstname=" + firstname + ", AddressLine1=" + AddressLine1 + ", AddressLine2=" + AddressLine2 + ", city=" + city + ", postalCode=" + postalCode + ", phone=" + phone + ", admin=" + admin + ", googleAuth=" + googleAuth + '}';
    }

    public int getAdmin() {
        return admin;
    }

    public void setAdmin() {
        admin = 1;
    }
    
}
