/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package JavaClasses;

import java.io.Serializable;

/**
 * This googleAuth class simple holds the data for the googleauth database and provides basie functionality for the
 * object like add, delete, edit and display.
 * @author Michael
 */
public class googleAuth {
    
    private int authID;
    private String username;
    private String Key;

    public googleAuth(int authID, String username, String Key) {
        this.authID = authID;
        this.username = username;
        this.Key = Key;
    }
    
    public googleAuth(String username, String Key) {
        this.username = username;
        this.Key = Key;
    }

    public int getAuthID() {
        return authID;
    }

    public void setAuthID(int authID) {
        this.authID = authID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String Key) {
        this.Key = Key;
    }

    @Override
    public String toString() {
        return "googleAuth{" + "authID=" + authID + ", username=" + username + ", Key=" + Key + '}';
    }
    
    
    
}
