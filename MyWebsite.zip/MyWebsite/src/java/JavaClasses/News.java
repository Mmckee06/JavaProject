/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package JavaClasses;

import java.io.Serializable;

/**
 * This news class simple holds the data for the news database and provides basie functionality for the
 * object like add, delete, edit and display.
 * @author Michael
 */
public class News implements Serializable{
    
    private int newsId;
    private String description;

    public News(String description) {
        this.description = description;
    }

    public News(int newsId, String description) {
        this.newsId = newsId;
        this.description = description;
    }

    public int getNewsId() {
        return newsId;
    }

    public void setNewsId(int newsId) {
        this.newsId = newsId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + this.newsId;
        hash = 23 * hash + (this.description != null ? this.description.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final News other = (News) obj;
        if (this.newsId != other.newsId) {
            return false;
        }
        if ((this.description == null) ? (other.description != null) : !this.description.equals(other.description)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "News{" + "newsId=" + newsId + ", description=" + description + '}';
    }
    
    public void display(){
        System.out.printf(" %-10s %-10s \n",
            newsId, description);
    }
    
}
