/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaClasses;

import java.io.Serializable;

/**
 * This PremTable class simple holds the data for the premiership database and provides basie functionality for the
 * object like add, delete, edit and display.
 * @author mmckee
 */
public class PremTable implements Serializable {
    
    private int TeamId;
    private int TeamPos;
    private String TeamName;
    private int GamesPlayed;
    private int GoalsFor;
    private int GoalsAgainst;
    private int GoalDifference;
    private int points;
    
    public PremTable(){
        TeamId = 0;
        TeamPos=0;
        TeamName = "";
        GamesPlayed = 0;
        GoalsFor = 0;
        GoalsAgainst = 0;
        GoalDifference = 0;
        points = 0;
    }
    
    public PremTable(int TeamId,int TeamPos,String TeamName, int GamesPlayed, int GoalsFor, int GoalsAgainst, int GoalDifference, int points){
        this.TeamId = TeamId;
        this.TeamPos= TeamPos;
        this.TeamName= TeamName;
        this.GamesPlayed = GamesPlayed;
        this.GoalsFor = GoalsFor;
        this.GoalsAgainst = GoalsAgainst;
        this.GoalDifference = GoalDifference;
        this.points = points;
        
    }
    
    public PremTable(int TeamPos,String TeamName, int GamesPlayed, int GoalsFor, int GoalsAgainst, int GoalDifference, int points){
        
        this.TeamPos= TeamPos;
        this.TeamName= TeamName;
        this.GamesPlayed = GamesPlayed;
        this.GoalsFor = GoalsFor;
        this.GoalsAgainst = GoalsAgainst;
        this.GoalDifference = GoalDifference;
        this.points = points;
        
    }

    public int getTeamId() {
        return TeamId;
    }

    public void setTeamId(int TeamId) {
        this.TeamId = TeamId;
    }

    public int getTeamPos() {
        return TeamPos;
    }

    public void setTeamPos(int TeamPos) {
        this.TeamPos = TeamPos;
    }

    public String getTeamName() {
        return TeamName;
    }

    public void setTeamName(String TeamName) {
        this.TeamName = TeamName;
    }

    public int getGamesPlayed() {
        return GamesPlayed;
    }

    public void setGamesPlayed(int GamesPlayed) {
        this.GamesPlayed = GamesPlayed;
    }

    public int getGoalsFor() {
        return GoalsFor;
    }

    public void setGoalsFor(int GoalsFor) {
        this.GoalsFor = GoalsFor;
    }

    public int getGoalsAgainst() {
        return GoalsAgainst;
    }

    public void setGoalsAgainst(int GoalsAgainst) {
        this.GoalsAgainst = GoalsAgainst;
    }

    public int getGoalDifference() {
        return GoalDifference;
    }

    public void setGoalDifference(int GoalDifference) {
        this.GoalDifference = GoalDifference;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.TeamId;
        hash = 79 * hash + this.TeamPos;
        hash = 79 * hash + (this.TeamName != null ? this.TeamName.hashCode() : 0);
        hash = 79 * hash + this.GamesPlayed;
        hash = 79 * hash + this.GoalsFor;
        hash = 79 * hash + this.GoalsAgainst;
        hash = 79 * hash + this.GoalDifference;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PremTable other = (PremTable) obj;
        if (this.TeamId != other.TeamId) {
            return false;
        }
        if (this.TeamPos != other.TeamPos) {
            return false;
        }
        if ((this.TeamName == null) ? (other.TeamName != null) : !this.TeamName.equals(other.TeamName)) {
            return false;
        }
        if (this.GamesPlayed != other.GamesPlayed) {
            return false;
        }
        if (this.GoalsFor != other.GoalsFor) {
            return false;
        }
        if (this.GoalsAgainst != other.GoalsAgainst) {
            return false;
        }
        if (this.GoalDifference != other.GoalDifference) {
            return false;
        }
        if (this.points != other.points) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "PremTable{" + "TeamId=" + TeamId + ", TeamPos=" + TeamPos + ", TeamName=" + TeamName + ", GamesPlayed=" + GamesPlayed + ", GoalsFor=" + GoalsFor + ", GoalsAgainst=" + GoalsAgainst + ", GoalDifference=" + GoalDifference + ", points=" + points + '}';
    }
    
    public void display(){
        System.out.printf("%10d  %-10s%-10s%-10s%-10s%-10s%-10s%-10s\n",
            TeamId, TeamPos, TeamName, GamesPlayed, GoalsFor, GoalsAgainst, GoalDifference, points);
    }
    
    public void ModifyPoints(int num){
        points = points + num;
    }
    
    public void ModifyGoalDifference(int Glsfor, int against ){
        GoalsFor = GoalsFor + Glsfor;
        GoalsAgainst = GoalsAgainst + against;
        GoalDifference = GoalDifference + (GoalsFor - GoalsAgainst);
        
    }
    
    
    
    
}
