package ActionServet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Michael
 */


import DAO.MyDatasource;
import DAO.UserDAO;
import DAO.googleAuthDAO;
import Exceptions.DaoException;
import JavaClasses.Store;
import JavaClasses.User;
import JavaClasses.googleAuth;
import Services.UserService;
import Services.googleAuthService;
import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;
import command.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class checkLoginServlet
 */
@WebServlet(urlPatterns={"/UserActionServlet"})
public class UserActionServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserActionServlet() 
    {
        super();
        // TODO Auto-generated constructor stub
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
      processRequest(request, response);     
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
      processRequest(request, response);  
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the end destination as a backup, in case something goes wrong
        String forwardToJsp = "/Homepage.jsp";
        try {
        //Check the 'action' parameter to see what the user wants...
        if ( request.getParameter("action") != null) 
        {
            // Create a LoginCommand and execute it
            CommandFactory factory = CommandFactory.getInstance();
            Command command = factory.createCommand(request.getParameter("action"));
            // execute generated Command
            forwardToJsp = command.execute(request, response);
        } else if (request.getParameter("action1").equalsIgnoreCase("Get Google Authenticator")) 
            { 
                HttpSession session = request.getSession(); 
                int code = (int) session.getAttribute("authCode");
            User user = (User)session.getAttribute("user");
                if (code == 1) { 
                    googleAuthService g1 = new googleAuthService();
                   googleAuth u1 = (googleAuth) g1.FindUser(user.getUsername());
                    String Key = u1.getKey();
                    session.setAttribute("secretKey", Key);
                    
                    
                    forwardToJsp = "/Homepage.jsp"; 
                } else { 
                GoogleAuthenticator googleAuthenticator = new GoogleAuthenticator();
                
        final GoogleAuthenticatorKey key = googleAuthenticator.createCredentials(user.getUsername()); 
        final String secretKey = key.getKey(); 
        final List<Integer> scratchCodes = key.getScratchCodes();
        
        String url = GoogleAuthenticatorKey.getQRBarcodeURL(user.getUsername(), "footyWebsite", secretKey);
        forwardToJsp = "/GoogleAuth.jsp";
        session.setAttribute("KeyImage", url); 
        session.setAttribute("secretKey", secretKey); 
        user.setGoogleAuth(1);
        UserService s1 = new UserService();
        s1.ChangeGoogleAuth(user.getUsername(),1);
        googleAuthDAO dao = new googleAuthDAO(new MyDatasource());
        googleAuth a = new googleAuth(user.getUsername(),secretKey);
                    try {
                        dao.addKey(a);
                    } catch (DaoException ex) {
                        Logger.getLogger(UserActionServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
       for (Integer i : scratchCodes) { 
        //if (!googleAuthenticator.validateScratchCode(i)) { 
            //throw new IllegalArgumentException("An invalid code has been " + "generated: this is an application bug.");
       } } 
            } else if (request.getParameter("action1").equalsIgnoreCase("Check Code")) {
           int code = Integer.parseInt(request.getParameter("code"));
        HttpSession session = request.getSession();
        User user = (User)session.getAttribute("user");
        String secretKey = (String)session.getAttribute("secretKey");
        
        if (code > 0)
        {
              
         
        GoogleAuthenticator ga = new GoogleAuthenticator();
        ga.setWindowSize(5);  //should give 5 * 30 seconds of grace...

        boolean isCodeValid = ga.authorize(secretKey, code);
        
        //System.out.println("Check VALIDATION_CODE = " + isCodeValid);
    
             
             if (isCodeValid == true){
                String clientSessionId = session.getId();
                 session.setAttribute("loggedSessionId", clientSessionId);
                session.setAttribute("user", user);
                session.setAttribute("authCode", user.getGoogleAuth());
                // create basket
                ArrayList<Store>  SessionItems = new ArrayList<Store>();
                session.setAttribute("basket",SessionItems );
                
                forwardToJsp = "/Homepage.jsp"; 
            } else {
                 forwardToJsp = "/Login2.jsp";
             }
           
        } else {
            forwardToJsp = "/Login2.jsp";
        }
           
       }

        }catch(NumberFormatException e) {
            forwardToJsp = "/Homepage.jsp"; 
        } catch(NullPointerException e) {
            forwardToJsp = "/Homepage.jsp"; 
        }
        
        //Get the request dispatcher object and forward the request to the appropriate JSP page...
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(forwardToJsp);
        dispatcher.forward(request, response);
    }
        
        
}
