/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Tests;

import DAO.MyDatasource;
import DAO.newsDAO;
import Exceptions.DaoException;
import JavaClasses.News;
import java.util.List;

/**
 *
 * @author Michael
 */
public class TestNewsDAO {
    
    public static void main(String[] args) {
        try {
            TestNewsDAO t = new TestNewsDAO();
            t.testFindAllNews();
            
        } catch (DaoException e) {
            System.out.println("ERROR: " + e.getMessage());
        }

    }
    
    
   public void testFindAllNews() throws DaoException {
        System.out.println("testFindAllNews()");
        try {
            newsDAO dao = new newsDAO( new MyDatasource() );

            //UserDAO dao = new UserDAO();

            List<News> news = dao.findAllNews();
            if (news.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (News u : news) {
                    u.display();
                }
            }
        } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
    }
    
}
