/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Tests;

import DAO.MyDatasource;
import Exceptions.DaoException;
import java.util.List;
import JavaClasses.Product_Order;
import DAO.Product_OrderDAO;
/**
 *
 * @author Michael
 */
public class TestProduct_OrdersDAO {
    
    public static void main(String[] args) {
        try {
            TestProduct_OrdersDAO t = new TestProduct_OrdersDAO();
            t.testFindAllProducts();
            t.testAddProduct();
            t.testAmendProductOrder();
            
        } catch (DaoException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
    
    public void testFindAllProducts() throws DaoException {
        System.out.println("testFindAllProducts()");
        try {
            //Product_OrderDAO dao = new Product_OrderDAO();
            Product_OrderDAO dao = new Product_OrderDAO( new MyDatasource() );

            List<Product_Order> items = dao.findAllProducts();
            if (items.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (Product_Order u : items) {
                    u.display();
                }
            }
        } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
    }
        
        public void testAddProduct() throws DaoException {
        System.out.println("testAddProduct()");
            try {
            //Product_OrderDAO dao = new Product_OrderDAO();
           Product_OrderDAO dao = new Product_OrderDAO( new MyDatasource() );
           Product_Order u = new Product_Order(1,2,3);
           
            dao.addProduct(u);
            System.out.println(u.toString());
            
                
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
        
       public void testAmendProductOrder() throws DaoException {
        System.out.println("testAmendProductOrder()");
            try {
            //Product_OrderDAO dao = new Product_OrderDAO();
           Product_OrderDAO dao = new Product_OrderDAO( new MyDatasource() );
           Product_Order u = new Product_Order(1,2,3);
           
           u.setSalesId(2);
           u.setItemId(3);
           u.setAmount(100);
           dao.amendProductOrder(u);
           
           System.out.println(u.toString());
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }

    }
    

