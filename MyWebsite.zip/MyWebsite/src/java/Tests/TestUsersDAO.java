/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

import DAO.MyDatasource;
import Exceptions.DaoException;
import java.util.List;
import JavaClasses.User;
import DAO.UserDAO;

/**
 *
 * @author mmckee
 */
public class TestUsersDAO {
    
     public static void main(String[] args) {
        try {
            TestUsersDAO t = new TestUsersDAO();
            t.testFindAllUsers();
            t.testFindPlayerByUsername();
            t.testFindPlayerByUsernamePassword();
            t.testAmendUserNameAddress();
            t.testAmendContactNumber();
            t.testAddUser();
            t.testDeleteUser();
            t.testFindAllUsers();
            //t.testAdmin();
        } catch (DaoException e) {
            System.out.println("ERROR: " + e.getMessage());
        }

    }
    
    
   public void testFindAllUsers() throws DaoException {
        System.out.println("testFindAllUsers()");
        try {
            UserDAO dao = new UserDAO( new MyDatasource() );

            //UserDAO dao = new UserDAO();

            List<User> users = dao.findAllUsers();
            if (users.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (User u : users) {
                    u.display();
                }
            }
        } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
    }
   
   public void testFindPlayerByUsername() throws DaoException {
        System.out.println("testFindUserByUsername()");
        try {
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );
            
            String username = "mmckee";
            User p = dao.findUsersByUsername(username);
            if (p == null) {
                System.out.println("No such user " + username);
            } else {
                p.display();
            }
            
            username = "mckee";
            p = dao.findUsersByUsername(username);
            if (p == null) {
                System.out.println("No such player " + username);
            } else {
                p.display();
            }
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
        
        public void testFindPlayerByUsernamePassword() throws DaoException {
        System.out.println("testFindUserByUsernamePassword()");
        try {
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );

            String username = "mmckee";
            String password = "password1";
            User p = dao.findUsersByUsernamePassword(username,password);
            if (p == null) {
                System.out.println("No such user " + username);
            } else {
                p.display();
            }
            
            username = "mckee";
             password = "password1";
             p = dao.findUsersByUsernamePassword(username,password);
            if (p == null) {
                System.out.println("No such user matches username and password " + username);
            } else {
                p.display();
            }
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
        
    public void testAmendUserNameAddress() throws DaoException {
        System.out.println("testAmendUserAddress()");
            try {
            //UserDAO dao = new UserDAO();
                UserDAO dao = new UserDAO( new MyDatasource() );
            User u = dao.findUsersByUsername("mmckee");
            u.setLastname("MCKEEE");
            u.setFirstname("Micky");
            u.setAddressLine1("37 Ballymacauley Rd");
            u.setAddressLine2("Seg");
            u.setCity("County Armagh");
            u.setPostalCode("BT60 2EP");
            u.setPhone("3434324332");
            
            dao.amendUserNameAddress(u);
            
            if (u == null) {
                System.out.println("No such user " + u.getUsername());
            } else {
                u.display();
            }
            
      
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testAmendContactNumber() throws DaoException {
        System.out.println("testAmendContactNumber()");
            try {
            //UserDAO dao = new UserDAO();
                UserDAO dao = new UserDAO( new MyDatasource() );
            User u = dao.findUsersByUsername("mmckee");
            u.setPhone("0283755556");
            
            dao.amendContactNumber(u);
            
            if (u == null) {
                System.out.println("No such user " + u.getUsername());
            } else {
                u.display();
            }
            
      
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
   
   public void testAddUser() throws DaoException {
        System.out.println("testAddUser()");
            try {
            //UserDAO dao = new UserDAO();
             UserDAO dao = new UserDAO( new MyDatasource() );
           User u = new User("mick","mick10","Micheal","Mckee","35 Bally Rd","Seg","Armagh","bt60","453443",0,0);
           
            dao.addUser(u);
          
            u.display();
                
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
   
   public void testDeleteUser() throws DaoException {
        System.out.println("testDeleteUser()");
        try {
            //UserDAO dao = new UserDAO();
            UserDAO dao = new UserDAO( new MyDatasource() );

            String username = "foot10";
            User p = dao.findUsersByUsername(username);
            dao.deleteUser(username);
            
            if (p == null) {
                System.out.println("No such user " + username);
            } else {
                p.display();
            }
           
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
   
   public void testAdmin() throws DaoException {
        System.out.println("testAdmin()");
            try {
            //UserDAO dao = new UserDAO();
             UserDAO dao = new UserDAO( new MyDatasource() );
            User u = dao.findUsersByUsername("michael");
            u.setAdmin();
            
            dao.setAdmin(u);
            
            if (u == null) {
                System.out.println("No such user " + u.getUsername());
            } else {
                u.display();
            }
            
      
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
   
   
   
}
 
