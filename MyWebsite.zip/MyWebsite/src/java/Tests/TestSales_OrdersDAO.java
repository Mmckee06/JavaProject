/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Tests;

import DAO.MyDatasource;
import DAO.Sales_OrderDAO;
import Exceptions.DaoException;
import JavaClasses.Sales_Order;
import java.util.List;

/**
 *
 * @author Michael
 */
public class TestSales_OrdersDAO {
    
    public static void main(String[] args) {
        try {
            TestSales_OrdersDAO t = new TestSales_OrdersDAO();
            t.testFindAllOrders();
            t.testAddOrder();
            t.testFindOrderByCustID();
            t.testFindOrderBySalesID();
            t.testLastCustomersOrder();
            t.testDeleteOrder();
            
        } catch (DaoException e) {
            System.out.println("ERROR: " + e.getMessage());
            
        }

    }
    
    public void testFindAllOrders() throws DaoException {
        System.out.println("testFindAllItems()");
        try {
            //Sales_OrderDAO dao = new Sales_OrderDAO();
            Sales_OrderDAO dao = new Sales_OrderDAO( new MyDatasource() );

            List<Sales_Order> items = dao.findAllOrders();
            if (items.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (Sales_Order u : items) {
                    u.display();
                }
            }
        } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
    }
    
    public void testAddOrder() throws DaoException {
        System.out.println("testAddSale()");
            try {
            //Sales_OrderDAO dao = new Sales_OrderDAO();
            Sales_OrderDAO dao = new Sales_OrderDAO( new MyDatasource() );
           Sales_Order u = new Sales_Order(1,4,100);
           
            dao.addOrder(u);
            System.out.println(u.toString());
            
                
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testFindOrderByCustID() throws DaoException {
        System.out.println("testFindOrderByCustID()");
        try {
            //Sales_OrderDAO dao = new Sales_OrderDAO();
            Sales_OrderDAO dao = new Sales_OrderDAO( new MyDatasource() );

            int id = 1;
            List<Sales_Order> items = dao.findAllOrdersByCustID(id);
            
           if (items.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (Sales_Order u : items) {
                    u.display();
                }
            }
            
            
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testFindOrderBySalesID() throws DaoException {
        System.out.println("testFindOrderBySalesID()");
        try {
            //Sales_OrderDAO dao = new Sales_OrderDAO();
            Sales_OrderDAO dao = new Sales_OrderDAO( new MyDatasource() );

            int id = 1;
            Sales_Order order = dao.findItemsBySalesID(id);
            
           if (order == null) {
                System.out.println("No such order " + order);
            } else {
                order.display();
            }
            
            
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testLastCustomersOrder() throws DaoException {
        System.out.println("testLastCustomersOrder()");
        try {
            //Sales_OrderDAO dao = new Sales_OrderDAO();
            Sales_OrderDAO dao = new Sales_OrderDAO( new MyDatasource() );

            int id = 1;
            double total =100.00;
            int totalItems= 4;
            Sales_Order order = dao.findItemsForSalesID(id, totalItems, total);
            
           if (order == null) {
                System.out.println("No such order " + order);
            } else {
                order.display();
            }
            
            
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testDeleteOrder() throws DaoException {
        System.out.println("testDeleteItem()");
        try {
            //Sales_OrderDAO dao = new Sales_OrderDAO();
            Sales_OrderDAO dao = new Sales_OrderDAO( new MyDatasource() );

            Sales_Order s = dao.findItemsBySalesID(22);
            
            
            
            dao.deleteSaleBySalesID(22);
            
            if (s == null) {
                System.out.println("No such Item " + s);
            } else {
                s.display();
            }
           
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
}
