/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

import DAO.MyDatasource;
import DAO.PremTableDAO;
import Exceptions.DaoException;
import JavaClasses.PremTable;
import java.util.List;

/**
 *
 * @author mmckee
 */
public class TestPremTableDAO {
    
    public static void main(String[] args) {
        try {
            
            TestPremTableDAO t = new TestPremTableDAO();
            t.testFindAllTeams();
            t.testFindTeamByTeamName();
            t.testfindTeamsByPointsGreaterThan();
            t.testfindTeamsByPointsLessThan();
            t.testAddTeam();
            t.testDeleteTeam();
            t.testUpdatePoints();
            t.testFindAllTeams();
            
            
        } catch (DaoException e) {
            System.out.println("ERROR: " + e.getMessage());
        }

    }
    
    
    
    public void testFindAllTeams() throws DaoException {
        System.out.println("testFindAllTeams()");
        try {
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );

            List<PremTable> teams = dao.findAllTeams();
            if (teams.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (PremTable u : teams) {
                    u.display();
                }
            }
        } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
    }
    
    public void testFindTeamByTeamName() throws DaoException {
        System.out.println("testFindUserByTeamName()");
        try {
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );

            String teamname = "Man Utd";
            PremTable p = dao.findTeamByTeamName(teamname);
            if (p == null) {
                System.out.println("No such team " + teamname);
            } else {
                p.display();
            }
            
            teamname = "Wigan";
            p = dao.findTeamByTeamName(teamname);
            if (p == null) {
                System.out.println("No such team in league " + teamname);
            } else {
                p.display();
            }
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    
    public void testfindTeamsByPointsGreaterThan() throws DaoException {
        System.out.println("testfindTeamsByPointsGreaterThan())");
        try {
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );

            int points = 15 ;
            List<PremTable> teams = dao.findTeamsByPointsGreaterThan(points);
            if (teams.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (PremTable u : teams) {
                    u.display();
                }
            }
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testfindTeamsByPointsLessThan() throws DaoException {
        System.out.println("testfindTeamsByPointsLessThan())");
        try {
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );

            int points = 5 ;
            List<PremTable> teams = dao.findTeamsByPointsLessThan(points);
            if (teams.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (PremTable u : teams) {
                    u.display();
                }
            }
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testAddTeam() throws DaoException {
        System.out.println("testAddTeam()");
        try {
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );
            
            PremTable a = new PremTable(21,21,"Wigan",12,4,5,-1,12);

            dao.addTeam(a);
            
            if (a == null) {
                System.out.println("No such team " + a.getTeamName());
            } else {
                a.display();
            }
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testDeleteTeam() throws DaoException {
        System.out.println("testDeleteTeam()");
        try {
            //PremTableDAO dao = new PremTableDAO();
            PremTableDAO dao = new PremTableDAO( new MyDatasource() );
            
            
            String Team = "Wigan";
            PremTable a = dao.findTeamByTeamName(Team);

           dao.deleteTeam(Team);
            
            if (a == null) {
                System.out.println("No such team " + a.getTeamName());
            } else {
                a.display();
            }
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
     public void testUpdatePoints() throws DaoException {
        System.out.println("testUpdatePoints(");
            try {
            //PremTableDAO dao = new PremTableDAO();
                PremTableDAO dao = new PremTableDAO( new MyDatasource() );
            
            String teamname = "Man Utd";
            PremTable u = dao.findTeamByTeamName(teamname);
            
            u.ModifyGoalDifference(21, 3);
            u.ModifyPoints(3);
        
            
           dao.updatePoints(u);
           
            
            
            if (u == null) {
                System.out.println("No such team " + u.getTeamName());
            } else {
                u.display();
            }
            
      
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    
    
}
