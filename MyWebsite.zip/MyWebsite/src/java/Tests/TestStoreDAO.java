/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

import DAO.MyDatasource;
import Exceptions.DaoException;
import java.util.List;
import JavaClasses.Store;
import DAO.StoreDAO;

/**
 *
 * @author mmckee
 */
public class TestStoreDAO {
    
    public static void main(String[] args) {
        try {
            TestStoreDAO t = new TestStoreDAO();
            t.testFindAllItems();
            t.testFinditemsByType();
            t.testFinditemsByName();
            t.testDeleteItem();
            t.testAddItem();
            t.testAmendItem();
            t.testFindAllItems();
            
        } catch (DaoException e) {
            System.out.println("ERROR: " + e.getMessage());
            
        }

    }
    
    public void testFindAllItems() throws DaoException {
        System.out.println("testFindAllItems()");
        try {
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );

            List<Store> items = dao.findAllItems();
            if (items.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (Store u : items) {
                    u.display();
                }
            }
        } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
    }
    
    public void testFinditemsByType() throws DaoException {
        System.out.println("testFinditemsByType()");
        try {
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );

            String item = "Jersey";
            List<Store> items = dao.findItemsByType(item);
            
           if (items.isEmpty()) {
                System.out.println("List is empty");
            } else {
                for (Store u : items) {
                    u.display();
                }
            }
            
            
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testFinditemsByName() throws DaoException {
        System.out.println("testFindItemsByName()");
        try {
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );

            String item = "Man Utd Shirt Home";
            Store s = dao.findItemsByName(item);
            
            if (s == null) {
                System.out.println("No such item " + s);
            } else {
                s.display();
            }
            
            
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testAddItem() throws DaoException {
        System.out.println("testAddItem()");
            try {
            //StoreDAO dao = new StoreDAO();
                StoreDAO dao = new StoreDAO( new MyDatasource() );
            
           Store u = new Store(100,"Blue football","football",10,7.99,"images/no-Image.png");
           
            dao.addItem(u);
          
            //u.display();
                
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testDeleteItem() throws DaoException {
        System.out.println("testDeleteItem()");
        try {
            //StoreDAO dao = new StoreDAO();
            StoreDAO dao = new StoreDAO( new MyDatasource() );

            String Itemname = "Blue football";
            Store p = dao.findItemsByName(Itemname);
            int id = 7;
            
            dao.deleteItem(id);
            
            if (p == null) {
                System.out.println("No such Item " + Itemname);
            } else {
                p.display();
            }
           
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
    public void testAmendItem() throws DaoException {
        System.out.println("testAmendItem()");
            try {
             //StoreDAO dao = new StoreDAO();
             StoreDAO dao = new StoreDAO( new MyDatasource() );
            Store u = dao.findItemsByName("Man Utd Shirt Home");
            
            
            u.setItemType("Jersey");
            u.setPrice(39.99);
            
            dao.amendItem(u);
            
            
            if (u == null) {
                System.out.println("No such user " + u.getItemName());
            } else {
                u.display();
            }
            
      
    
            } catch (DaoException e) {
            System.out.println("Error " + e.getMessage());
        }
   }
    
}
