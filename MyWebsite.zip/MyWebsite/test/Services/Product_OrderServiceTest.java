/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import JavaClasses.Product_Order;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class Product_OrderServiceTest {
    
    public Product_OrderServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getAllProducts method, of class Product_OrderService.
     */
    @Test
    public void testGetAllProducts() {
        System.out.println("getAllProducts");
        Product_OrderService instance = new Product_OrderService();
        List<Product_Order> expResult = instance.getAllProducts();
        List<Product_Order> result = instance.getAllProducts();
        assertEquals(expResult, result);
    }


    /**
     * Test of addProduct method, of class Product_OrderService.
     */
    @Test
    public void testAddProduct() {
        System.out.println("addProduct");
        int salesID = 500;
        int itemID = 2;
        int amount = 2;
        Product_OrderService instance = new Product_OrderService();
        Product_Order expResult = new Product_Order(500,2,2);
        Product_Order result = instance.addProduct(salesID, itemID, amount);
        assertEquals(expResult, result);
    }

    /**
     * Test of DeleteProductBySalesID method, of class Product_OrderService.
     */
    @Test
    public void testDeleteProductBySalesID() {
        System.out.println("DeleteProductBySalesID");
        int salesID = 500;
        Product_OrderService instance = new Product_OrderService();
        Product_Order expResult = null;
        Product_Order result = instance.DeleteProductBySalesID(salesID);
        assertEquals(expResult, result);
    }
    
}
