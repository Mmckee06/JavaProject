/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import JavaClasses.News;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class newsServiceTest {
    
    public newsServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getAllNews method, of class newsService.
     */
    @Test
    public void testGetAllNews() {
        System.out.println("getAllNews");
        newsService instance = new newsService();
        List<News> expResult = instance.getAllNews();
        List<News> result = instance.getAllNews();
        assertEquals(expResult, result);
    }
    
}
