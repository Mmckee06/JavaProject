/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import JavaClasses.Sales_Order;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class Sales_OrderServiceTest {
    
    public Sales_OrderServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getAllSales method, of class Sales_OrderService.
     */
    @Test
    public void testGetAllSales() {
        System.out.println("getAllSales");
        Sales_OrderService instance = new Sales_OrderService();
        List<Sales_Order> expResult = instance.getAllSales();
        List<Sales_Order> result = instance.getAllSales();
        assertEquals(expResult, result);
    }

    /**
     * Test of getAllSalesByCustID method, of class Sales_OrderService.
     */
    @Test
    public void testGetAllSalesByCustID() {
        System.out.println("getAllSalesByCustID");
        int ID = 0;
        Sales_OrderService instance = new Sales_OrderService();
        List<Sales_Order> expResult = instance.getAllSalesByCustID(ID);
        List<Sales_Order> result = instance.getAllSalesByCustID(ID);
        assertEquals(expResult, result);
    }

    /**
     * Test of addOrder method, of class Sales_OrderService.
     */
    @Test
    public void testAddOrder() {
        System.out.println("addOrder");
        int custID = 4;
        int totalItems = 2;
        double total = 50.0;
        Sales_OrderService instance = new Sales_OrderService();
        Sales_Order expResult = new Sales_Order(4,2,50.0);
        Sales_Order result = instance.addOrder(custID, totalItems, total);
        assertEquals(expResult, result);
    }

    /**
     * Test of FindOrderForID method, of class Sales_OrderService.
     */
    @Test
    public void testFindOrderForID() {
        System.out.println("FindOrderForID");
        int custID = 1;
        int totalItems = 4;
        double Total = 119.96;
        Sales_OrderService instance = new Sales_OrderService();
        Sales_Order expResult = new Sales_Order(1,1,4,119.0);
        Sales_Order result = instance.FindOrderForID(custID, totalItems, Total);
        assertEquals(expResult, result);
    }

    /**
     * Test of DeleteBySalesID method, of class Sales_OrderService.
     */
    @Test
    public void testDeleteBySalesID() {
        System.out.println("DeleteBySalesID");
        int salesID = 21;
        Sales_OrderService instance = new Sales_OrderService();
        Sales_Order expResult = null;
        Sales_Order result = instance.DeleteBySalesID(salesID);
        assertEquals(expResult, result);
    }
    
}
