/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import JavaClasses.googleAuth;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class googleAuthServiceTest {
    
    public googleAuthServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of FindUser method, of class googleAuthService.
     */
    @Test
    public void testFindUser() {
        System.out.println("FindUser");
        String username = "paddy";
        googleAuthService instance = new googleAuthService();
        googleAuth expResult = null;
        googleAuth result = instance.FindUser(username);
        assertEquals(expResult, result);
    }

  

    

    
    
}
