/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import JavaClasses.User;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class UserServiceTest {
    
    public UserServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of login method, of class UserService.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        String username = "mmckee";
        String password = "password1";
        UserService instance = new UserService();
        User expResult = new User(1,"mmckee", "password1", "McKee", "Michael", "35 Bally Rd", "segahan", "Armagh", "bt50 2ep","02837542334",1,0);
        User result = instance.login(username, password);
        assertEquals("Failed testLogin() = mmckee",expResult, result);
        //System.out.println(result);
    }

    /**
     * Test of Register method, of class UserService.
     */
    @Test
    public void testRegister() {
        System.out.println("Register");
        String username = "foot20";
        String password = "football20";
        String LastName = "foot";
        String FirstName = "Bob";
        String AddressLine1 = "45";
        String AddressLine2 = "The Street";
        String City = "Dundalk";
        String POSTALCODE = "00000";
        String Phone = "53532532";
        int user_Type = 0;
        int googleAuth = 0;
        UserService instance = new UserService();
        User expResult = new User("foot20", "football20", "foot", "Bob", "45", "The Street", "Dundalk", "00000","53532532",0,0);
        User result = instance.Register(username, password, LastName, FirstName, AddressLine1, AddressLine2, City, POSTALCODE, Phone, user_Type,googleAuth);
        assertEquals("Failed testRegister() = foot20",expResult, result);
    }

    /**
     * Test of getAllUsers method, of class UserService.
     */
    @Test
    public void testGetAllUsers() {
        System.out.println("getAllUsers");
        UserService instance = new UserService();
        List<User> expResult = instance.getAllUsers();
        List<User> result = instance.getAllUsers();
        assertEquals("Failed ListAllUsers()",expResult, result);
    }

    /**
     * Test of ChangePassword method, of class UserService.
     */
    @Test
    public void testChangePassword() {
        System.out.println("ChangePassword");
        String username = "foot20";
        String OldPassword = "football20";
        String NewPassword = "foot20";
        UserService instance = new UserService();
        User expResult = new User(4,"foot20", "foot20", "foot", "Bobby", "555", "Street", "Dublin", "00000","2421412",1,0);
        User result = instance.ChangePassword(username, OldPassword, NewPassword);
        assertEquals("Failed changePassword()= foot20",expResult, result);
    }
    
    /**
     * Test of Register method, of class UserService.
     */
    @Test
    public void testRegister2() {
        System.out.println("Register");
        String username = "foot100";
        String password = "football20";
        String LastName = "foot";
        String FirstName = "Bob";
        String AddressLine1 = "45";
        String AddressLine2 = "The Street";
        String City = "Dundalk";
        String POSTALCODE = "00000";
        String Phone = "53532532";
        int user_Type = 0;
        int googleAuth = 0;
        UserService instance = new UserService();
        User expResult = new User("foot100", "football20", "foot", "Bob", "45", "The Street", "Dundalk", "00000","53532532",0,0);
        User result = instance.Register(username, password, LastName, FirstName, AddressLine1, AddressLine2, City, POSTALCODE, Phone, user_Type,googleAuth);
        assertEquals("Failed register2() = foot100",expResult, result);
    }

    /**
     * Test of ChangeAdmin method, of class UserService.
     */
    @Test
    public void testChangeAdmin() {
        System.out.println("ChangeAdmin");
        String username = "foot20";
        UserService instance = new UserService();
        User result = instance.ChangeAdmin(username);
        User expResult = new User(4,"foot20","foot20","foot","Bobby","555","Street","Dublin","00000","2421412",1,0);
        assertEquals("Failed TestChangeAdmin()= foot20",expResult, result);
    }
    
    
    /**
     * Test of Edit method, of class UserService.
     */
    @Test
    public void testEdit() {
        System.out.println("Edit");
        String username = "foot20";
        String LastName = "foot";
        String FirstName = "Bobby";
        String AddressLine1 = "555";
        String AddressLine2 = "Street";
        String City = "Dublin";
        String POSTALCODE = "00000";
        String Phone = "2421412";
        int user_Type = 0;
        int googleAuth = 0;
        UserService instance = new UserService();
        User expResult = new User(4,"foot20","foot20","foot","Bobby","555","Street","Dublin","00000","2421412",1,0);
        User result = instance.Edit(username, LastName, FirstName, AddressLine1, AddressLine2, City, POSTALCODE, Phone, user_Type);
        assertEquals("Failed testEdit() = foot20",expResult, result);
    }

    /**
     * Test of DeleteUser method, of class UserService.
     */
    @Test
    public void testDeleteUser() {
        System.out.println("DeleteUser");
        String username = "foot100";
        UserService instance = new UserService();
        User expResult = null;
        User result = instance.DeleteUser(username);
        assertEquals("Failed delete user == foot100",expResult, result);
    }

    /**
     * Test of FindUser method, of class UserService.
     */
    @Test
    public void testFindUser() {
        System.out.println("FindUser");
        String username = "foot20";
        UserService instance = new UserService();
        User expResult = new User(4,"foot20","foot20","foot","Bobby","555","Street","Dublin","00000","2421412",1,0);
        User result = instance.FindUser(username);
        assertEquals("Failed findUser() = foot20",expResult, result);
    }
    
}
