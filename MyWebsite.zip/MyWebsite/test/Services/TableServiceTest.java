/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// Run twice to work so add and delete team work along with each other
package Services;

import JavaClasses.PremTable;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class TableServiceTest {
    
    public TableServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getAllTeams method, of class TableService.
     */
    @Test
    public void testGetAllTeams() {
        System.out.println("getAllTeams");
        TableService instance = new TableService();
        List<PremTable> expResult = instance.getAllTeams();
        List<PremTable> result = instance.getAllTeams();
        assertEquals(expResult, result);
    }

    /**
     * Test of Edit method, of class TableService.
     */
    @Test
    public void testEdit() {
        System.out.println("Edit");
        String itemname = "Sunderland";
        int GamesPlayed = 12;
        int forGoal = 23;
        int against = 20;
        int dif = 3;
        int points = 12;
        TableService instance = new TableService();
        PremTable expResult = new PremTable(20,20,"Sunderland",12,23,20,3,12);
        PremTable result = instance.Edit(itemname, GamesPlayed, forGoal, against, dif, points);
        assertEquals(expResult, result);
    }

    /**
     * Test of addItem method, of class TableService.
     */
    @Test
    public void testAddItem() {
        System.out.println("addItem");
        int pos = 21;
        String itemname = "QPR";
        int GamesPlayed = 10;
        int forGoal = 21;
        int against = 18;
        int dif = 3;
        int points = 9;
        TableService instance = new TableService();
        PremTable expResult = new PremTable(21,"QPR",10,21,18,3,9);
        PremTable result = instance.addItem(pos, itemname, GamesPlayed, forGoal, against, dif, points);
        assertEquals(expResult, result);
    }

    /**
     * Test of DeleteTeam method, of class TableService.
     */
    @Test
    public void testDeleteTeam() {
        System.out.println("DeleteTeam");
        String teamname = "QPR";
        TableService instance = new TableService();
        PremTable expResult = null;
        PremTable result = instance.DeleteTeam(teamname);
        assertEquals(expResult, result);
    }
    
}
