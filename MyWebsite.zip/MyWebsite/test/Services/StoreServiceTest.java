/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Services;

import JavaClasses.Store;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class StoreServiceTest {
    
    public StoreServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getAllItems method, of class StoreService.
     */
    @Test
    public void testGetAllItems() {
        System.out.println("getAllItems");
        StoreService instance = new StoreService();
        List<Store> expResult = instance.getAllItems();
        List<Store> result = instance.getAllItems();
        assertEquals("Failed getAllItems()",expResult, result);
    }

    /**
     * Test of DeleteItem method, of class StoreService.
     */
    @Test
    public void testDeleteItem() {
        System.out.println("DeleteItem");
        int id = 5;
        StoreService instance = new StoreService();
        Store expResult = null;
        Store result = instance.DeleteItem(id);
        assertEquals("Failed DeleteItem() id = 5",expResult, result);
    }

    /**
     * Test of Edit method, of class StoreService.
     */
    @Test
    public void testEdit() {
        System.out.println("Edit");
        int ID = 4;
        String itemname = "Everton Blue Hat";
        String itemType = "Hat";
        int Quantity = 500;
        double Price = 10.0;
        String image = "images/no-Image.png";
        StoreService instance = new StoreService();
        Store expResult = new Store(4,"Everton Blue Hat","Hat",500,10.0,"images/no-Images.png");
        Store result = instance.Edit(ID, itemname, itemType, Quantity, Price,image);
        assertEquals("Failed Edit Id = 4",expResult, result);
    }

    /**
     * Test of addItem method, of class StoreService.
     */
    @Test
    public void testAddItem() {
        System.out.println("addItem");
        String itemname = "West Ham Shirt";
        String itemType = "jersey";
        int quantity = 50;
        double price = 40.0;
        String image = "images/no-Image.png";
        StoreService instance = new StoreService();
        Store expResult = new Store("West Ham Shirt","jersey",50,40.0,"images/no-Image.png");
        Store result = instance.addItem(itemname, itemType, quantity, price,image);
        assertEquals("Failed AddItem() = West Ham Shirt",expResult, result);
    }

    
    
}
