/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import JavaClasses.Store;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class StoreDAOTest {
    
    public StoreDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of findAllItems method, of class StoreDAO.
     */
    @Test
    public void testFindAllItems() throws Exception {
        System.out.println("findAllItems");
        StoreDAO instance = new StoreDAO( new MyDatasource() );
        List<Store> expResult = instance.findAllItems();
        List<Store> result = instance.findAllItems();
        assertEquals(expResult, result);
    }

    /**
     * Test of findItemsByType method, of class StoreDAO.
     */
    @Test
    public void testFindItemsByType() throws Exception {
        System.out.println("findItemsByType");
        String type = "Jersey";
        StoreDAO instance = new StoreDAO( new MyDatasource() );
        List<Store> expResult = instance.findItemsByType(type);
        List<Store> result = instance.findItemsByType(type);
        assertEquals(expResult, result);
    }

    /**
     * Test of findItemsByName method, of class StoreDAO.
     */
    @Test
    public void testFindItemsByName() throws Exception {
        System.out.println("findItemsByName");
        String Name = "Man Utd Shirt Home";
        StoreDAO instance = new StoreDAO( new MyDatasource() );
        Store expResult = new Store(2,"Man Utd Shirt Home","Jersey",100,29.99,"images/manutdHomeShirt.png");
        Store result = instance.findItemsByName(Name);
        assertEquals(expResult, result);
    }

    /**
     * Test of findItemsByID method, of class StoreDAO.
     */
    @Test
    public void testFindItemsByID() throws Exception {
        System.out.println("findItemsByID");
        int ID = 1;
        StoreDAO instance = new StoreDAO( new MyDatasource() );
        Store expResult = new Store(1,"Addidas Football","Football",1000,5.99,"images/football.png");
        Store result = instance.findItemsByID(ID);
        assertEquals(expResult, result);
    }

    /**
     * Test of addItem method, of class StoreDAO.
     */
    @Test
    public void testAddItem() throws Exception {
        System.out.println("addItem");
        Store u = new Store(20,"West Ham Home Shirt","Jersey",500,34.99,"images/westhamHomeShirt.png");
        StoreDAO instance = new StoreDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.addItem(u);
        assertEquals(expResult, result);
    }

    /**
     * Test of deleteItem method, of class StoreDAO.
     */
    @Test
    public void testDeleteItem() throws Exception {
        System.out.println("deleteItem");
        int ID = 20;
        StoreDAO instance = new StoreDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.deleteItem(ID);
        assertEquals(expResult, result);
    }

    /**
     * Test of amendItem method, of class StoreDAO.
     */
    @Test
    public void testAmendItem() throws Exception {
        System.out.println("amendItem");
        Store a = new Store(4,"Everton Hat","clothing",500,9.99,"images/evertonHat.png");;
        StoreDAO instance = new StoreDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.amendItem(a);
        assertEquals(expResult, result);
    }
    
}
