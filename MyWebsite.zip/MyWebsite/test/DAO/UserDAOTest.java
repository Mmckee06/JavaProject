/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import JavaClasses.User;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class UserDAOTest {
    
    public UserDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of findAllUsers method, of class UserDAO.
     */
    @Test
    public void testFindAllUsers() throws Exception {
        System.out.println("findAllUsers");
        UserDAO instance = new UserDAO( new MyDatasource() );
        List<User> expResult = instance.findAllUsers();
        List<User> result = instance.findAllUsers();
        assertEquals(expResult, result);
    }

    /**
     * Test of findUsersByUsername method, of class UserDAO.
     */
    @Test
    public void testFindUsersByUsername() throws Exception {
        System.out.println("findUsersByUsername");
        String uname = "mmckee";
        UserDAO instance = new UserDAO( new MyDatasource() );
        User expResult = new User(1,"mmckee", "password1", "McKee", "Michael", "35 Bally Rd", "segahan", "Armagh", "bt50 2ep","02837542334",1,0);
        User result = instance.findUsersByUsername(uname);
        assertEquals(expResult, result);
    }

    /**
     * Test of findUsersByUsernamePassword method, of class UserDAO.
     */
    @Test
    public void testFindUsersByUsernamePassword() throws Exception {
        System.out.println("findUsersByUsernamePassword");
        String uname = "mmckee";
        String upass = "password1";
        UserDAO instance = new UserDAO( new MyDatasource() );
        User expResult = new User(1,"mmckee", "password1", "McKee", "Michael", "35 Bally Rd", "segahan", "Armagh", "bt50 2ep","02837542334",1,0);
        User result = instance.findUsersByUsernamePassword(uname, upass);
        assertEquals(expResult, result);
    }

    /**
     * Test of amendUserNameAddress method, of class UserDAO.
     */
    @Test
    public void testAmendUserNameAddress() throws Exception {
        System.out.println("amendUserNameAddress");
        User u = new User("paddy1", "pad1", "Smith", "Paddy", "46 Dundalk Rd", "Hoeys Lane", "Dundalk", "000023","56546353",0,0);
        UserDAO instance = new UserDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.amendUserNameAddress(u);
        assertEquals(expResult, result);
    }


    /**
     * Test of addUser method, of class UserDAO.
     */
    @Test
    public void testAddUser() throws Exception {
        System.out.println("addUser");
        User u = new User("paddy200", "pad1", "Smith", "Paddy", "46 Dundalk Rd", "Hoeys Lane", "Dundalk", "000023","56546353",0,0);;
        UserDAO instance = new UserDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.addUser(u);
        assertEquals(expResult, result);
    }

    /**
     * Test of deleteUser method, of class UserDAO.
     */
    @Test
    public void testDeleteUser() throws Exception {
        System.out.println("deleteUser");
        String Username = "paddy200";
        UserDAO instance = new UserDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.deleteUser(Username);
        assertEquals(expResult, result);
    }

    /**
     * Test of changePassword method, of class UserDAO.
     */
    @Test
    public void testChangePassword() throws Exception {
        System.out.println("changePassword");
        User u = new User("paddy1", "pad1", "Smith", "Paddy", "46 Dundalk Rd", "Hoeys Lane", "Dundalk", "000023","56546353",0,0);
        String OldPassword = "pad2";
        String NewPassword = "pad2";
        UserDAO instance = new UserDAO( new MyDatasource() );
        int expResult = 0;
        int result = instance.changePassword(u, OldPassword, NewPassword);
        assertEquals(expResult, result);
    }

    /**
     * Test of setAdmin method, of class UserDAO.
     */
    @Test
    public void testSetAdmin() throws Exception {
        System.out.println("setAdmin");
        User c = new User("foot10", "football", "Hughes", "Mary", "78 mowhan Rd", "Antrim", "Antrim", "bt65 8ep","656456",0,0);
        UserDAO instance = new UserDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.setAdmin(c);
        assertEquals(expResult, result);
    }
    
}
