/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import JavaClasses.Sales_Order;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class Sales_OrderDAOTest {
    
    public Sales_OrderDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of findAllOrders method, of class Sales_OrderDAO.
     */
    @Test
    public void testFindAllOrders() throws Exception {
        System.out.println("findAllOrders");
        Sales_OrderDAO instance = new Sales_OrderDAO( new MyDatasource() );
        List<Sales_Order> expResult = instance.findAllOrders();
        List<Sales_Order> result = instance.findAllOrders();
        assertEquals(expResult, result);
    }

    /**
     * Test of findAllOrdersByCustID method, of class Sales_OrderDAO.
     */
    @Test
    public void testFindAllOrdersByCustID() throws Exception {
        System.out.println("findAllOrdersByCustID");
        int CustID = 1;
        Sales_OrderDAO instance = new Sales_OrderDAO( new MyDatasource() );
        List<Sales_Order> expResult = instance.findAllOrdersByCustID(CustID);
        List<Sales_Order> result = instance.findAllOrdersByCustID(CustID);
        assertEquals(expResult, result);
    }

    /**
     * Test of addOrder method, of class Sales_OrderDAO.
     */
    @Test
    public void testAddOrder() throws Exception {
        System.out.println("addOrder");
        Sales_Order u = new Sales_Order(100,1,2,100.00);
        Sales_OrderDAO instance = new Sales_OrderDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.addOrder(u);
        assertEquals(expResult, result);
    }

    /**
     * Test of findItemsBySalesID method, of class Sales_OrderDAO.
     */
    @Test
    public void testFindItemsBySalesID() throws Exception {
        System.out.println("findItemsBySalesID");
        int ID = 2;
        Sales_OrderDAO instance = new Sales_OrderDAO( new MyDatasource() );
        Sales_Order expResult = new Sales_Order(2,1,3,89.0);
        Sales_Order result = instance.findItemsBySalesID(ID);
        assertEquals(expResult, result);
    }

    /**
     * Test of findItemsForSalesID method, of class Sales_OrderDAO.
     */
    @Test
    public void testFindItemsForSalesID() throws Exception {
        System.out.println("findItemsForSalesID");
        int CusID = 1;
        int totalItems = 6;
        double total1 = 35.94;
        Sales_OrderDAO instance = new Sales_OrderDAO( new MyDatasource() );
        Sales_Order expResult = null;
        Sales_Order result = instance.findItemsForSalesID(CusID, totalItems, total1);
        assertEquals(expResult, result);
    }

    /**
     * Test of findOrderByCustID method, of class Sales_OrderDAO.
     */
    @Test
    public void testFindOrderByCustID() throws Exception {
        System.out.println("findOrderByCustID");
        int ID = 1;
        Sales_OrderDAO instance = new Sales_OrderDAO( new MyDatasource() );
        Sales_Order expResult = instance.findOrderByCustID(ID);
        Sales_Order result = instance.findOrderByCustID(ID);
        assertEquals(expResult, result);
    }

    /**
     * Test of deleteSaleBySalesID method, of class Sales_OrderDAO.
     */
    @Test
    public void testDeleteSaleBySalesID() throws Exception {
        System.out.println("deleteSaleBySalesID");
        int SalesID = 100;
        Sales_OrderDAO instance = new Sales_OrderDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.deleteSaleBySalesID(SalesID);
        assertEquals(expResult, result);
    }
    
}
