/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import JavaClasses.googleAuth;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class googleAuthDAOTest {
    
    public googleAuthDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of findAllAuths method, of class googleAuthDAO.
     */
    @Test
    public void testFindAllAuths() throws Exception {
        System.out.println("findAllAuths");
        googleAuthDAO instance = new googleAuthDAO( new MyDatasource() );
        List<googleAuth> expResult = instance.findAllAuths();
        List<googleAuth> result = instance.findAllAuths();
        assertEquals(expResult, result);
    }

    /**
     * Test of addKey method, of class googleAuthDAO.
     */
    @Test
    public void testAddKey() throws Exception {
        System.out.println("addKey");
        googleAuth u = new googleAuth(1001,"TestUser","TestKey");
        googleAuthDAO instance = new googleAuthDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.addKey(u);
        assertEquals(expResult, result);
    }

    /**
     * Test of findAuthByUsername method, of class googleAuthDAO.
     */
    @Test
    public void testFindAuthByUsername() throws Exception {
        System.out.println("findAuthByUsername");
        String uname = "paddy";
        googleAuthDAO instance = new googleAuthDAO( new MyDatasource() );
        googleAuth expResult = null;
        googleAuth result = instance.findAuthByUsername(uname);
        assertEquals(expResult, result);
    }

    /**
     * Test of deleteAuthByID method, of class googleAuthDAO.
     */
    @Test
    public void testDeleteAuthByID() throws Exception {
        System.out.println("deleteAuthByID");
        int ID = 1001;
        googleAuthDAO instance = new googleAuthDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.deleteAuthByID(ID);
        assertEquals(expResult, result);
    }

    /**
     * Test of findAuthByID method, of class googleAuthDAO.
     */
    @Test
    public void testFindAuthByID() throws Exception {
        System.out.println("findAuthByID");
        int ID1 = 1001;
        googleAuthDAO instance = new googleAuthDAO( new MyDatasource() );
        googleAuth expResult = null;
        googleAuth result = instance.findAuthByID(ID1);
        assertEquals(expResult, result);
    }
    
}
