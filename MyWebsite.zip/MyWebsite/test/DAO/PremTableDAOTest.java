/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import JavaClasses.PremTable;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class PremTableDAOTest {
    
    public PremTableDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of findAllTeams method, of class PremTableDAO.
     */
    @Test
    public void testFindAllTeams() throws Exception {
        System.out.println("findAllTeams");
        PremTableDAO instance = new PremTableDAO( new MyDatasource() );
        List<PremTable> expResult = instance.findAllTeams();
        List<PremTable> result = instance.findAllTeams();
        assertEquals(expResult, result);
    }

    /**
     * Test of findTeamByTeamName method, of class PremTableDAO.
     */
    @Test
    public void testFindTeamByTeamName() throws Exception {
        System.out.println("findTeamByTeamName");
        String team = "Swansea";
        PremTableDAO instance = new PremTableDAO( new MyDatasource() );
        PremTable expResult = new PremTable(11,11,"Swansea",8,12,11,1,10);
        PremTable result = instance.findTeamByTeamName(team);
        assertEquals(expResult, result);
    }

    /**
     * Test of findTeamsByPointsGreaterThan method, of class PremTableDAO.
     */
    @Test
    public void testFindTeamsByPointsGreaterThan() throws Exception {
        System.out.println("findTeamsByPointsGreaterThan");
        int point = 18;
        PremTableDAO instance = new PremTableDAO( new MyDatasource() );
        List<PremTable> expResult = instance.findTeamsByPointsGreaterThan(point);
        List<PremTable> result = instance.findTeamsByPointsGreaterThan(point);
        assertEquals(expResult, result);
    }

    /**
     * Test of findTeamsByPointsLessThan method, of class PremTableDAO.
     */
    @Test
    public void testFindTeamsByPointsLessThan() throws Exception {
        System.out.println("findTeamsByPointsLessThan");
        int point = 4;
        PremTableDAO instance = new PremTableDAO( new MyDatasource() );
        List<PremTable> expResult = instance.findTeamsByPointsLessThan(point);
        List<PremTable> result = instance.findTeamsByPointsLessThan(point);
        assertEquals(expResult, result);
    }

    /**
     * Test of addTeam method, of class PremTableDAO.
     */
    @Test
    public void testAddTeam() throws Exception {
        System.out.println("addTeam");
        PremTable u = new PremTable(25,16,"Wigan",8,8,13,-5,1);
        PremTableDAO instance = new PremTableDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.addTeam(u);
        assertEquals(expResult, result);
    }

    /**
     * Test of deleteTeam method, of class PremTableDAO.
     */
    @Test
    public void testDeleteTeam() throws Exception {
        System.out.println("deleteTeam");
        String Teamname = "Wigan";
        PremTableDAO instance = new PremTableDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.deleteTeam(Teamname);
        assertEquals(expResult, result);
    }

    /**
     * Test of updatePoints method, of class PremTableDAO.
     */
    @Test
    public void testUpdatePoints() throws Exception {
        System.out.println("updatePoints");
        PremTable u = new PremTable(6,6,"Southampton",8,8,3,5,16);
        PremTableDAO instance = new PremTableDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.updatePoints(u);
        assertEquals(expResult, result);
    }
    
}
