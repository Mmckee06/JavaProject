/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import JavaClasses.Product_Order;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Michael
 */
public class Product_OrderDAOTest {
    
    public Product_OrderDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of findAllProducts method, of class Product_OrderDAO.
     */
    @Test
    public void testFindAllProducts() throws Exception {
        System.out.println("findAllProducts");
        Product_OrderDAO instance = new Product_OrderDAO( new MyDatasource() );
        List<Product_Order> expResult = instance.findAllProducts();
        List<Product_Order> result = instance.findAllProducts();
        assertEquals(expResult, result);;
    }

    /**
     * Test of findProductssBySalesOrderID method, of class Product_OrderDAO.
     */
    @Test
    public void testFindProductssBySalesOrderID() throws Exception {
        System.out.println("findProductssBySalesOrderID");
        int ID = 3;
        Product_OrderDAO instance = new Product_OrderDAO( new MyDatasource() );
        List<Product_Order> expResult = instance.findProductssBySalesOrderID(ID);
        List<Product_Order> result = instance.findProductssBySalesOrderID(ID);
        assertEquals(expResult, result);
    }

    /**
     * Test of addProduct method, of class Product_OrderDAO.
     */
    @Test
    public void testAddProduct() throws Exception {
        System.out.println("addProduct");
        Product_Order u = new Product_Order(1000,2,1,100);
        Product_OrderDAO instance = new Product_OrderDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.addProduct(u);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of addProduct method, of class Product_OrderDAO.
     */
    @Test
    public void testAddProduct1() throws Exception {
        System.out.println("addProduct");
        Product_Order u = new Product_Order(999,2,2,100);
        Product_OrderDAO instance = new Product_OrderDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.addProduct(u);
        assertEquals(expResult, result);
    }

    /**
     * Test of deleteProductByProductOrderID method, of class Product_OrderDAO.
     */
    @Test
    public void testDeleteProductByProductOrderID() throws Exception {
        System.out.println("deleteProductByProductOrderID");
        int ProductOrderID = 1000;
        Product_OrderDAO instance = new Product_OrderDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.deleteProductByProductOrderID(ProductOrderID);
        assertEquals(expResult, result);
    }

    /**
     * Test of deleteProductBySalesID method, of class Product_OrderDAO.
     */
    @Test
    public void testDeleteProductBySalesID() throws Exception {
        System.out.println("deleteProductBySalesID");
        int SalesID = 2;
        Product_OrderDAO instance = new Product_OrderDAO( new MyDatasource() );
        int expResult = 1;
        int result = instance.deleteProductBySalesID(SalesID);
        assertEquals(expResult, result);
    }

    
    
}
