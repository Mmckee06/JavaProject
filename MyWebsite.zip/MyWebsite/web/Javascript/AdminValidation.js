/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
window.onload = startForm;

function startForm() {
		//document.Admin1.Uname.focus();
                document.Admin1.onsubmit = checkForm1;
                document.Admin2.onsubmit = checkForm2;
                document.Admin3.onsubmit = checkForm3;
                document.Admin4.onsubmit = checkForm4;
		document.Admin1.onreset = resetForm1;
	}
		
function resetForm1() {
	location.reload();
	}
				
function checkForm1() {
                if (document.Admin1.Uname.value.length == 0) {
                        alert("You MUST enter a UserName!");
                        document.Admin1.Uname.focus();
                        return false;
		} else if (document.Admin1.OldPassword.value.length == 0) {
			alert("You MUST enter a Old Password");
			document.Admin1.OldPassword.focus();
			return false;
                } else if (document.Admin1.NewPassword.value.length == 0) {
			alert("You MUST enter a New Password");
			document.Admin1.NewPassword.focus();
			return false;
                } 
              
          }
function checkForm2() {
                if (document.Admin2.Uname.value.length == 0) {
                        alert("You MUST enter a UserName!");
                        document.Admin2.Uname.focus();
                        return false;
		} 	
 }
 
 function checkForm3() {
                if (document.Admin3.itemName.value.length == 0) {
                        alert("You MUST enter a item Name");
                        document.Admin3.itemName.focus();
                        return false;
		} 	
 }
 
 function checkForm4() {
                if (document.Admin4.id.value.length == 0) {
                        alert("You MUST enter a ID");
                        document.Admin4.id.focus();
                        return false;
		} 	
 }
                

            
      
                
          
