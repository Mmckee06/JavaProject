window.onload = startForm;

function startForm() {
                document.AddPremTeam.onsubmit = checkForm1;
        }
		
function resetForm1() {
	location.reload();
	}
			
 

function checkForm1() {
                if (document.AddPremTeam.position.value.length == 0) {
                        alert("You MUST enter a Position");
                        document.AddPremTeam.position.focus();
                        return false;
                } else if (document.AddPremTeam.teamName.value.length == 0) {
                        alert("You MUST enter a Team Name");
                        document.AddPremTeam.teamName.focus();
                        return false;
		} else 	if (document.AddPremTeam.GamesPlayed.value.length == 0) {
                        alert("You MUST enter Games Played");
                        document.AddPremTeam.GamesPlayed.focus();
                        return false;
                } else 	if (document.AddPremTeam.GoalsFor.value.length == 0) {
                        alert("You MUST enter Goals For");
                        document.AddPremTeam.GoalsFor.focus();
                        return false;
                } else 	if (document.AddPremTeam.GoalsAgainst.value.length == 0) {
                        alert("You MUST enter Goals Against");
                        document.AddPremTeam.GoalsFor.focus();
                        return false;
                } else 	if (document.AddPremTeam.GoalDifference.value.length == 0) {
                        alert("You MUST enter Goal Difference");
                        document.AddPremTeam.GoalDifference.focus();
                        return false;
                } else 	if (document.AddPremTeam.points.value.length == 0) {
                        alert("You MUST enter Points");
                        document.AddPremTeam.points.focus();
                        return false;
                }
 }


function checkForm3() {
                if (document.deleteTeam.teamname.value.length == 0) {
                        alert("You MUST enter a Team Name");
                        document.deleteTeam.teamname.focus();
                        return false;   
                    }
 }
 
 function checkTextField(teamName,GamesPlayed,GoalsFor,GoalsAgainst,GoalDifference,points) {
    if (teamName.value == '') {
        alert("No Team Name entered");
       
        
    }
    if (GamesPlayed.value == '') {
        alert("No Games Played entered");
        document.adminTable.GamesPlayed.focus();
    }
    if (GoalsFor.value == '') {
        alert("No Goals For entered");
        document.adminTable.GoalsFor.focus();
    }
    if (GoalsAgainst.value == '') {
        alert("No Goals Against entered");
        
    }
    if (GoalDifference.value == '') {
        alert("No Goal Difference entered");
        
    }
    if (points.value == '') {
        alert("No Points entered");
        
    }
}