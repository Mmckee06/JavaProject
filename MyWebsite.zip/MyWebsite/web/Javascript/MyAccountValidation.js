
window.onload = startForm;

function startForm() {
		
                document.account.onsubmit = checkForm1;
		document.account.onreset = resetForm1;
	}
		
function resetForm1() {
	location.reload();
	}
			
 
 function checkForm1() {
                if (document.account.OldPassword.value.length == 0) {
                        alert("You MUST enter a Old Password");
                        document.account.OldPassword.focus();
                        return false;
		} else 	if (document.account.NewPassword.value.length == 0) {
                        alert("You MUST enter a New Password");
                        document.account.NewPassword.focus();
                        return false;
                 }
   }

