/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


window.onload = startForm;

function startForm() {
                //document.addItem.itemName.focus();
		//document.Admin3.itemName.focus();
                document.addItem.onsubmit = checkForm1;
                document.editItem.onsubmit = checkForm2;
                document.addDiscount.onsubmit = checkForm3;
               
	}
		
function resetForm1() {
	location.reload();
	}
			
 
 function checkForm1() {
                if (document.addItem.itemName.value.length == 0) {
                        alert("You MUST enter a item Name");
                        document.addItem.itemName.focus();
                        return false;
		} else if (document.addItem.itemType.value.length == 0) {
                        alert("You MUST enter a item Type");
                        document.addItem.itemType.focus();
                        return false;
                 }else if (document.addItem.quantity.value.length == 0) {
                        alert("You MUST enter a quantity");
                        document.addItem.quantity.focus();
                        return false;
                 } else if (document.addItem.price.value.length == 0) {
                        alert("You MUST enter a price");
                        document.addItem.price.focus();
                        return false;
                 } else if (document.addItem.Image.value.length == 0) {
                        alert("You MUST enter a Image URL");
                        document.addItem.Image.focus();
                        return false;
                 }
 }
 
 function checkForm2() {
                if (document.editItem.price.length == 0) {
                        alert("You MUST enter a ItemName");
                        document.ItemName.price.focus();
                        return false;
		} 
         
 }
 
  function checkForm3() {
                if (document.addDiscount.discount.value.length == 0) {
                        alert("You MUST enter a Discount");
                        document.addDiscount.discount.focus();
                        return false;
		} 
   }
 
 function checkTextField(ItemName,ItemType,quantity,price,Image) {
    if (ItemName.value == '') {
        alert("No Item Name entered");
        document.getElementById('ItemName').focus();
        
    }
    if (ItemType.value == '') {
        alert("No Item Type entered");
    }
    if (quantity.value == '') {
        alert("No quantity entered");
    }
        
    if (price.value == '') {
        alert("No price entered");
    }
    if (Image.value == '') {
        alert("No image entered");
        
    }
}
 
 
 