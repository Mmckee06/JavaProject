
window.onload = startForm;

function startForm() {
		document.forms[0].Uname.focus();
                document.forms[0].onsubmit = checkForm1;
		document.forms[0].onreset = resetForm1;
	}
		
function resetForm1() {
	location.reload();
	}
				
function checkForm1() {
                if (document.forms[0].Uname.value.length == 0) {
                        alert("You MUST enter a UserName");
                        document.forms[0].Uname.focus();
                        return false;
		} else if (document.forms[0].password.value.length == 0) {
                        alert("You MUST enter a Password");
                        document.forms[0].password.focus();
                        return false;
		} else if (document.forms[0].fname.value.length == 0) {
                        alert("You MUST enter a First Name");
                        document.forms[0].fname.focus();
                        return false;
		} else if (document.forms[0].lname.value.length == 0) {
			alert("You MUST enter a Last Name");
			document.forms[0].lname.focus();
			return false;
                } else if (document.forms[0].Address1.value.length == 0) {
			alert("You MUST enter a AddressLine1");
			document.forms[0].Address1.focus();
			return false;
                } else if (document.forms[0].city.value.length == 0) {
			alert("You MUST enter a City");
			document.forms[0].city.focus();
			return false;
               // } else if (document.forms[0].pcode.value.length == 0) {
			//alert("You MUST enter a PostalCode");
			//document.forms[0].pcode.focus();
			//return false;
                } else if (document.forms[0].phone.value.length == 0) {
			alert("You MUST enter a Phone Number");
			document.forms[0].phone.focus();
			return false;
                } 
                

            
      
                
          }
              
                  
