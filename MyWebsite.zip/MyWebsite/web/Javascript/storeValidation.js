/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

window.onload = startForm;

function startForm() {
		document.Admin1.quantity.focus();
                document.Admin1.onsubmit = checkForm1;
		document.Admin1.onreset = resetForm1;
	}
		
function resetForm1() {
	location.reload();
	}
				
function checkForm1() {
                if (document.Admin1.quantity.length == "") {
                        alert("You MUST enter the quantity you want!");
                        document.Admin1.quantity.focus();
                        return false;
		} 
          }
          
 function checkTextField(field) {
    if (field.value == '') {
        alert("No quantity entered");
        field.value = 0;
    }
}
