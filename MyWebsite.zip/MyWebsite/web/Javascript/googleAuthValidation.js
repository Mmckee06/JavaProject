/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

window.onload = startForm;

function startForm() {
                document.verify.code.focus();
                document.verify.onsubmit = checkForm1;
               
	}
		
function resetForm1() {
	location.reload();
	}
			
 
 function checkForm1() {
                if (document.verify.code.value.length == 0) {
                        alert("You MUST enter a code");
                        document.verify.code.focus();
                        return false;
		} 
 }
